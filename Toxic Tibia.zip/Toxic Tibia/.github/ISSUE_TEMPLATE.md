<!-- 
  To open an issue in the project you must follow the guideline below.
  More information about how to format you text: https://guides.github.com/features/mastering-markdown/
-->
### Subject of the issue
Describe your issue here.

### Tibia Version
- [ ] 10.00
- [ ] 11.00
- [ ] Other

### Steps to reproduce
How to reproduce this issue.

### Expected behaviour
What should happen.

### Actual behaviour
What happens instead.
