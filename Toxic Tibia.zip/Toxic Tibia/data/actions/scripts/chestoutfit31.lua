local config = {
   storage = 7511,
   outfit_male = 0,
   outfit_female = 2521,
   outfit_name = "Claudia Poke Leader",
}

function onUse(cid, item, frompos, item2, topos)

   if getPlayerStorageValue(cid, config.storage) < 1 then
      doCreatureSay(cid, "Acabas de obtener el outfit ".. config.outfit_name ..".", TALKTYPE_ORANGE_1)
      doPlayerAddOutfit(cid, config.outfit_male, 3)
      doPlayerAddOutfit(cid, config.outfit_female, 3)
      setPlayerStorageValue(cid, config.storage, 1)
   else
      doPlayerSendCancel(cid, "Esta vacio.")
   end
   
   return true
end