local outfits = {
 
-- Config
	dollID = 39670, -- Change this to your dolls or items, item ID
 
	-- Main Window Messages (The first window the player sees)
	mainTitle = "Choose an outfit",
	mainMsg = "You will recieve both addons aswell as the outfit you choose.",
 
	-- Already Owned Window (The window that appears when the player already owns the addon)
	ownedTitle = "Whoops!",
	ownedMsg = "You already have this addon. Please choose another.",
 
	-- No Doll in Backpack (The window that appears when the player doesnt have the doll in their backpack)
	dollTitle = "Whoops!",
	dollMsg = "The outfits doll must be in your backpack.",
-- End Config
	-- Outfit Table
	[1] = {name = "Archangel", female = 1852},
	[2] = {name = "Space Warrior", female = 1853},
	[3] = {name = "Samurai", female = 1850},
	[4] = {name = "Rascoohan", female = 1882},
	[5] = {name = "Ninja", female = 1898},
	[6] = {name = "Raccoon", female = 1885},
	[7] = {name = "Pirat", female = 1875},
	[8] = {name = "Alchemist", female = 1851},
	[9] = {name = "Chaos Master", female = 1960},
	[10] = {name = "Satanic Warrior", female = 1963},
	[11] = {name = "Rogue", female = 1964},
	[12] = {name = "Legionary", female = 1968},
	[13] = {name = "Royal Bounacean Advisor", female = 2036},
	[14] = {name = "Kyubi", female = 2045},
	[15] = {name = "Frankenstein", female = 2044},
	[16] = {name = "Debora", female = 2048},
	[17] = {name = "Jasmine", female = 2049},
	[18] = {name = "Whitney", female = 2051},
	[19] = {name = "Psychic Trainer", female = 2053},
	[20] = {name = "Fly Trainer", female = 2054},
	[21] = {name = "Winona", female = 2056},
	[22] = {name = "Flannery", female = 2057},
	[23] = {name = "Roxanne", female = 2058},
	[24] = {name = "Runner", female = 2061},
	[25] = {name = "Hermione", female = 2065},
	[26] = {name = "Sexy Bunny", female = 2067},
	[27] = {name = "Team Rocket", female = 2069},
    [28] = {name = "Bunny", female = 2070},
	[29] = {name = "Sexy Box", female = 2074},
	[30] = {name = "Sakura", female = 2081},
	[31] = {name = "Hinata", female = 2082},
	[32] = {name = "Ino", female = 2083},
	[33] = {name = "Ten-ten", female = 2084},
	[34] = {name = "Konan", female = 2085},
	[35] = {name = "Konan 3D", female = 2108},
	[36] = {name = "Sunnade", female = 2088},
	[37] = {name = "Kaguya", female = 2096},
	[38] = {name = "Hero Trainer", female = 2103},
	[39] = {name = "Princess Trainer", female = 2104},
	[40] = {name = "Tashigi", female = 2156},
	[41] = {name = "Nami", female = 2174},
	[42] = {name = "Emily", female = 2312},
	[43] = {name = "Atlante", female = 2329},
	[44] = {name = "Poke Girl", female = 2331},
	[45] = {name = "Harley Quinn", female = 2334},
	[46] = {name = "Girl Venusaur", female = 2348},
	[47] = {name = "Lady Venusaur", female = 2353},
	[48] = {name = "Athena", female = 2354},
	[49] = {name = "Porygon", female = 2360},
	[50] = {name = "Gallina", female = 2364},
	[51] = {name = "Gallina2", female = 2364},

}
 
function onUse(player, item, fromPosition, itemEx, toPosition, isHotkey)
    player:sendAddonWindow(outfits)
    return true
end