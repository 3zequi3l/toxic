local mounts = {
-- Config
	dollID = 39590, -- Change this to your dolls or items, item ID
 
	-- Main Window Messages (The first window the player sees)
	mainTitle = "Choose a Mount!",
	mainMsg = "Choose a mount to unlock.",
 
	-- Already Owned Window (The window that appears when the player already owns the addon)
	ownedTitle = "Whoops!",
	ownedMsg = "You already have this mount. Please choose another.",
 
	-- No Doll in Backpack (The window that appears when the player doesnt have the doll in their backpack)
	dollTitle = "Whoops!",
	dollMsg = "The mount doll must be in your backpack.",
-- End Config
 
		[1] = {name = "Hydra", ID = 169},
		[2] = {name = "Metagross", ID = 170},
		[3] = {name = "Quara Pincher", ID = 171},
		[4] = {name = "Hellhound", ID = 172},
		[5] = {name = "Demon Turtle", ID = 173},
		[6] = {name = "Yielothax", ID = 174},
		[7] = {name = "Magma Crawler", ID = 175},
		[8] = {name = "Ariados", ID = 176},
		[9] = {name = "Mossmasher", ID = 177},
		[10] = {name = "Sandscourge", ID = 178},
		[11] = {name = "Golem", ID = 179},
		[12] = {name = "Zubejo", ID = 180},
		
    }
 
function onUse(player, item, fromPosition, itemEx, toPosition, isHotkey)
	player:sendMountWindow(mounts)
end