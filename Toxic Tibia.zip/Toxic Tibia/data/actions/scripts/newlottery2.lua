local decayItems = {
	[1945] = 1946, [1946] = 1945
}
local slots = {
	-- aqui sao os slots da esteira, por onde os itens vao ir passando... podem ser adicionados quantos quiser...
	Position(54, 171, 7), Position(55, 171, 7), Position(56, 171, 7), Position(57, 171, 7),	Position(58, 171, 7),
	Position(59, 171, 7), Position(60, 171, 7), Position(61, 171, 7), Position(62, 171, 7)
}

local itemtable = {
	--aqui pode ter ate 100 itens.. a chance nunca pode se repetir, ela deve ser de 1 a 100...
	-- inserir os itens respeitando a ordem: [1], [2], [3], ...  ate o ultimo [100]
	[1] = {id = 2148, chance = 1},
	[2] = {id = 2398, chance = 5},
	[3] = {id = 2386, chance = 10},
	[4] = {id = 2643, chance = 15},
	[5] = {id = 2461, chance = 20},
	[6] = {id = 2510, chance = 25},
	[7] = {id = 2649, chance = 30},
	[8] = {id = 2643, chance = 35},
	[9] = {id = 2647, chance = 40},
	[10] = {id = 9078, chance = 45},
	[11] = {id = 2490, chance = 50},
	[12] = {id = 2457, chance = 55},
	[13] = {id = 2152, chance = 56},
	
	
	[16] = {id = 38961, chance = 68},
	[17] = {id = 38953, chance = 69},
	[18] = {id = 39164, chance = 70},
	[19] = {id = 39163, chance = 71},
	[20] = {id = 39165, chance = 72},
	[21] = {id = 38948, chance = 74},
	[22] = {id = 39161, chance = 75},
	[23] = {id = 38947, chance = 76},
	[24] = {id = 38943, chance = 77},
	[25] = {id = 38942, chance = 78},
	
	
	[26] = {id = 38945, chance = 79},
	[27] = {id = 38946, chance = 80},
	[28] = {id = 38944, chance = 81},
	[29] = {id = 38950, chance = 82},
	
	[30] = {id = 39209, chance = 83},
	[31] = {id = 38930, chance = 84},
	[32] = {id = 38974, chance = 85},
	[33] = {id = 38979, chance = 86},
	
	
	[34] = {id = 38929, chance = 87},
	[35] = {id = 38927, chance = 88},
	[36] = {id = 7409, chance = 89},
	[37] = {id = 38928, chance = 90},
	
	
	
	[38] = {id = 39228, chance = 91},
	[39] = {id = 38963, chance = 92},
	[40] = {id = 38960, chance = 93},
	[41] = {id = 39205, chance = 94},
	[42] = {id = 38985, chance = 95},
	[43] = {id = 39230, chance = 96},
	[44] = {id = 39219, chance = 97},
	[45] = {id = 39225, chance = 98},
	[46] = {id = 39226, chance = 99},
	
	
	
	
	
	
	[14] = {id = 2160, chance = 57},
	[15] = {id = 2159, chance = 58}
}

local function ender(cid, position)
	local player = Player(cid)
	local posicaofim = Position(58, 171, 7) -- AQUI VAI APARECER A SETA, que define o item que o player ganhou
	local item = Tile(posicaofim):getTopDownItem()
	if item then
		local itemId = item:getId()
		posicaofim:sendMagicEffect(CONST_ME_TUTORIALARROW)
		player:addItem(itemId, 1)
	end
	local alavanca = Tile(position):getTopDownItem()
	if alavanca then
		alavanca:setActionId(18564) -- aqui volta o actionid antigo, para permitir uma proxima jogada...
	end
	if itemId == 2159 or itemId == 2160 then --checar se é o ID do item LENDARIO
		broadcastMessage("O player "..player:getName().." ganhou "..item:getName().."", MESSAGE_EVENT_ADVANCE) -- se for item raro mandar no broadcast
		
		for _, pid in ipairs(getPlayersOnline()) do
			if pid ~= cid then
				pid:say("O player "..player:getName().." ganhou "..item:getName().."", TALKTYPE_MONSTER_SAY) -- se nao for lendario, mandar uma mensagem comum
			end
		end
	end
end

local function delay(position, aux)
	local item = Tile(position):getTopDownItem()
	if item then
		local slot = aux + 1
		item:moveTo(slots[slot])
	end	
end

local function exec(cid)
	--calcular uma chance e atribuir um item
	local rand = math.random(1, 100)
	local aux, memo = 0, 0
	if rand >= 1 then
		for i = 1, #itemtable do
			local randitemid = itemtable[i].id
			local randitemchance = itemtable[i].chance
			if rand >= randitemchance then
				aux = aux + 1
				memo = randitemchance
			end
			
		end
	end
	-- Passo um: Criar um item no primeiro SLOT, e deletar se houver o item do ultimo slot.
	Game.createItem(itemtable[aux].id, 1, slots[1])
	slots[1]:sendMagicEffect(CONST_ME_POFF)
	local item = Tile(slots[#slots]):getTopDownItem()
	if item then
		item:remove()
	end
	--Passo dois: Mover itens para o proximo slot em todos os slots de 1 a 12 para o 2 > 13
	local maxslot = #slots-1
	local lastloop = 0
	for i = 1, maxslot do
		
		addEvent(delay, 1*1*60, slots[i], i)
	end
end

function onUse(cid, item, fromPosition, itemEx, toPosition)
	local player = Player(cid)
	if not player then
		return false
	end
	if not player:removeItem(10945, 1) then -- PARA JOGAR o player precisa ter o item 5091, que representa um bilhete vendido na store ou em um npc....
		return false
	end
	
	item:transform(decayItems[item.itemid])
	item:decay()	
	--muda actionid do item para nao permitir executar duas instancias
	item:setActionId(18565)
	
	local segundos = 30
	local loopsize = segundos*2
	
	for i = 1, loopsize do
		addEvent(exec, 1*i*500, cid.uid)
	end
	addEvent(ender, (1*loopsize*500)+1000, cid.uid, fromPosition)
	
	return true
end
