local potions = {
-- Config
	titleMsg = "Choose your Potion",
	mainMsg = "Please select how many potions you would like to buy.",
	moneyMsg = "You do not have enough money!", -- This is the message the player will recieve when he does not have enough money.
	capacityMsg = "I need more cap", -- This is the message the player will recieve when he does not have enough capactiy.
	buyMsg = "You have bought ", -- This is the message the player will recieve when he succesfully buys.
-- End Config
 
	-- Change prices in this table here price10 = price for 10 potions etc.
    [1] = {potion = "Mana Fluid (Level 250)", itemID = 27323, price10 = 5000, price50 = 25000, price100 = 50000},
    [2] = {potion = "Life Fluid (Level 300)", itemID = 27321, price10 = 5000, price50 = 25000, price100 = 50000},
    [3] = {potion = "Spirit Fluid (Level 250)", itemID = 27322, price10 = 5000, price50 = 25000, price100 = 50000},
    [4] = {potion = "Bullseye Potion", itemID = 7443, price10 = 50000, price50 = 250000, price100 = 500000},
    [5] = {potion = "Berserk Potion", itemID = 7439, price10 = 50000, price50 = 250000, price100 = 500000},
    [6] = {potion = "Mastermind Potion", itemID = 7440, price10 = 50000, price50 = 250000, price100 = 500000},
	[7] = {potion = "Super Sudden Death Rune (Level 200)", itemID = 2263, price10 = 2000, price50 = 10000, price100 = 20000},
	[8] = {potion = "super Avalanche Rune (Level 200)", itemID = 2275, price10 = 2000, price50 = 10000, price100 = 20000},
	[9] = {potion = "Super Fireball Rune (Level 200)", itemID = 2306, price10 = 2000, price50 = 10000, price100 = 20000},
	[10] = {potion = "Super Poison Rune (Level 200)", itemID = 23723, price10 = 2000, price50 = 10000, price100 = 20000},
	[11] = {potion = "Super Energy Ball Rune (Level 200)", itemID = 2264, price10 = 2000, price50 = 10000, price100 = 20000},
	[6] = {potion = "Mastermind Potion", itemID = 7440, price10 = 2000, price50 = 10000, price100 = 20000},
	[6] = {potion = "Mastermind Potion", itemID = 7440, price10 = 2000, price50 = 10000, price100 = 20000},
    
}
 
function onUse(player, item, fromPosition, itemEx, toPosition, isHotkey)
    player:sendShopWindow(potions)
    return true
end