local config = {
-- Window Config
	mainTitleMsg = "Crafting System", -- Main window title
	mainMsg = "Welcome to the crafting system. Please choose a vocation to begin.", -- Main window message
 
	craftTitle = "Crafting System: ", -- Title of the crafting screen after player picks of vocation
	craftMsg = "Here is a list of all items that can be crafted for the ", -- Message on the crafting screen after player picks of vocation
-- End Window Config
 
-- Player Notifications Config
	needItems = "You do not have all the required items to make ", -- This is the message the player recieves if he does not have all required items
 
-- Crafting Config
	system = {
	[1] = {vocation = "Master Sorcerer", -- This is the category can be anything.
			items = {
				[1] = {item = "Wand Of Satanic Skull", -- item name (THIS MUST BE EXACT OR IT WILL NOT WORK!)
						itemID = 28127, -- item to be made
						reqItems = { -- items and the amounts in order to craft.
								[1] = {item = 39749, count = 1}, -- malignous wand
								[2] = {item = 38927, count = 1}, -- ragnar wand
								[3] = {item = 38929, count = 1}, -- infernal skull wand
								[4] = {item = 39347, count = 1}, -- wand of ruler hades
								[5] = {item = 39369, count = 1}, -- wand of darkness dragon
								[6] = {item = 39359, count = 1}, -- wand of fire soul
								[7] = {item = 6551, count = 100}, -- Boss Dust
								[8] = {item = 6549, count = 100}, -- Dorne Powder
							},
						},
 
				[2] = {item = "red jungle legs(3% mana extra)",
						itemID = 39460,		
						reqItems = {
								[1] = {item = 6551, count = 100}, -- Boss Dust
								[2] = {item = 6549, count = 100}, -- Dorne Powder
								[3] = {item = 38895, count = 1}, -- supreme legs
								[4] = {item = 38871, count = 1}, -- golden skirt
								[5] = {item = 38770, count = 1}, -- shadow fire legs
								[6] = {item = 38900, count = 1}, -- garden legs
								[7] = {item = 38901, count = 1}, -- black legs
								[8] = {item = 38894, count = 1}, -- skull legs
								[9] = {item = 38896, count = 1}, -- volcanic legs
								[10] = {item = 38833, count = 1}, -- crystal legs
								[11] = {item = 18400, count = 1}, -- gill legs
								[12] = {item = 38683, count = 1}, -- soulshanks
								[13] = {item = 2495, count = 1}, -- demon legs
								[14] = {item = 7730, count = 1}, -- blue legs
								[15] = {item = 2504, count = 1}, -- dwarven legs
								[16] = {item = 38835, count = 1}, -- necromancer legs
								[17] = {item = 38954, count = 1}, -- shogun legs
								[18] = {item = 30884, count = 1}, -- gnome legs
								[19] = {item = 39297, count = 1}, -- wizard legs
								[20] = {item = 39255, count = 1}, -- elite blue legs
							},
						},					
 
				[3] = {item = "red jungle boots(2% mana extra)",
						itemID = 39463,			
						reqItems = {
							      [1] = {item = 6551, count = 100}, -- Boss Dust
								[2] = {item = 6549, count = 100}, -- Dorne Powder
								[3] = {item = 2195, count = 1}, -- boots of haste
								[4] = {item = 2645, count = 1}, -- steel boots
								[5] = {item = 9932, count = 1}, -- firewalker boots
								[6] = {item = 2640, count = 1}, -- pair of soft boots
								[7] = {item = 25412, count = 1}, -- treader of torment
								[8] = {item = 38752, count = 1}, -- hydra boots
								[9] = {item = 38750, count = 1}, -- desert boots
								[10] = {item = 38751, count = 1}, -- celestial boots
								[11] = {item = 34062, count = 1}, -- pair of dreamwalkers
								[12] = {item = 38946, count = 1}, -- dark wing boots
								[13] = {item = 38945, count = 1}, -- red wings boots
						},
					},
				},
			},
 
	[2] = {vocation= "Elder Druid", 
			items = {
				[1] = {item = "Rod of Herbolary Magic",
						itemID = 27988,
						reqItems = {
							    [1] = {item = 39751, count = 1}, -- saint water rod
								[2] = {item = 38928, count = 1}, -- oceanborn rod
								[3] = {item = 7409, count = 1}, -- northen rod
								[4] = {item = 39360, count = 1}, -- crystalline rod
								[5] = {item = 39362, count = 1}, -- saint ice rod
								[6] = {item = 39355, count = 1}, -- garden rod
								[7] = {item = 39353, count = 1}, -- ancient muck rod
								[8] = {item = 6551, count = 100}, -- Boss Dust
								[9] = {item = 6549, count = 100}, -- Dorne Powder
						},
					},
 
				[2] = {item = "jungle legs(3% mana extra)",
						itemID = 39461,				
						reqItems = {
							    [1] = {item = 6551, count = 100}, -- Boss Dust
								[2] = {item = 6549, count = 100}, -- Dorne Powder
								[3] = {item = 38895, count = 1}, -- supreme legs
								[4] = {item = 38871, count = 1}, -- golden skirt
								[5] = {item = 38770, count = 1}, -- shadow fire legs
								[6] = {item = 38900, count = 1}, -- garden legs
								[7] = {item = 38901, count = 1}, -- black legs
								[8] = {item = 38894, count = 1}, -- skull legs
								[9] = {item = 38896, count = 1}, -- volcanic legs
								[10] = {item = 38833, count = 1}, -- crystal legs
								[11] = {item = 7730, count = 1}, -- Blue legs
								[12] = {item = 38888, count = 1}, -- nahual legs
								[13] = {item = 38955, count = 1}, -- Japon Legs
								[14] = {item = 38684, count = 1}, -- Soulstrider
								[15] = {item = 2504, count = 1}, -- Dwarven legs
								[16] = {item = 30884, count = 1}, -- gnome legs
								[17] = {item = 18400, count = 1}, -- gill legs
								[18] = {item = 2495, count = 1}, -- demon legs
								[19] = {item = 39297, count = 1}, -- wizard legs
								[20] = {item = 39255, count = 1}, -- elite blue legs
						},
					},
 
				[3] = {item = "jungle boots(2% mana extra)",
						itemID = 39464,				
						reqItems = {
							     [1] = {item = 6551, count = 100}, -- Boss Dust
								[2] = {item = 6549, count = 100}, -- Dorne Powder
								[3] = {item = 2195, count = 1}, -- boots of haste
								[4] = {item = 2645, count = 1}, -- steel boots
								[5] = {item = 9932, count = 1}, -- firewalker boots
								[6] = {item = 2640, count = 1}, -- pair of soft boots
								[7] = {item = 25412, count = 1}, -- treader of torment
								[8] = {item = 38752, count = 1}, -- hydra boots
								[9] = {item = 38750, count = 1}, -- desert boots
								[10] = {item = 38751, count = 1}, -- celestial boots
								[11] = {item = 34062, count = 1}, -- pair of dreamwalkers
								[12] = {item = 38950, count = 1}, -- purplex boots
								[13] = {item = 38944, count = 1}, -- blue wing boots
						},
					},
				},
			},
 
		[3] = {vocation = "Royal Paladin", 
				items = {
					[1] = {item = "Power Arbalest",
							itemID = 27914,
							reqItems = {
								[1] = {item = 39746, count = 1}, -- Nomad Crossbow
								[2] = {item = 39441, count = 1}, -- Dark Master Crossbow
								[3] = {item = 38843, count = 1}, -- Magic Crossbow
								[4] = {item = 39234, count = 1}, -- Basilisk Crossbow
								[5] = {item = 38961, count = 1}, -- Hades Crossbow
								[6] = {item = 6551, count = 100}, -- Boss Dust
								[7] = {item = 6549, count = 100}, -- Dorne Powder
							},
						},
 
					[2] = {item = "Power Bow",
							itemID = 27982,		
							reqItems = {
								[1] = {item = 39747, count = 1}, -- Nomad Bow
								[2] = {item = 38952, count = 1}, -- Hades Bow
								[3] = {item = 38953, count = 1}, -- Halcon Bow
								[4] = {item = 38842, count = 1}, -- Vampire Bow
								[5] = {item = 39235, count = 1}, -- Poison Bow
								[6] = {item = 39350, count = 1}, -- Spike Bow
								[7] = {item = 39352, count = 1}, -- Prismatic Bow
								[8] = {item = 39354, count = 1}, --Wooden Bow
								[9] = {item = 39371, count = 1}, -- Undead Bow
								[10] = {item = 6551, count = 100}, -- Boss Dust
								[11] = {item = 6549, count = 100}, -- Dorne Powder
							},
						},						
 
					[3] = {item = "predator legs(3% health extra)",
							itemID = 28138,				
							reqItems = {
								[1] = {item = 6551, count = 100}, -- Boss Dust
								[2] = {item = 6549, count = 100}, -- Dorne Powder
								[3] = {item = 38895, count = 1}, -- supreme legs
								[4] = {item = 38871, count = 1}, -- golden skirt
								[5] = {item = 38770, count = 1}, -- shadow fire legs
								[6] = {item = 38900, count = 1}, -- garden legs
								[7] = {item = 38901, count = 1}, -- black legs
								[8] = {item = 38894, count = 1}, -- skull legs
								[9] = {item = 38896, count = 1}, -- volcanic legs
								[10] = {item = 38833, count = 1}, -- crystal legs
								[11] = {item = 37452, count = 1}, -- fabulous legs
								[12] = {item = 39215, count = 1}, -- sparkion legs
								[13] = {item = 2495, count = 1}, -- demon legs
								[14] = {item = 18405, count = 1}, -- prismatic legs
								[15] = {item = 32420, count = 1}, -- falcon greaves
								[16] = {item = 9777, count = 1}, -- yalahari leg piece
								[17] = {item = 2504, count = 1}, -- dwarven legs
								[18] = {item = 39256, count = 1}, -- cormaya legs
								[19] = {item = 38872, count = 1}, -- dragunov legs
							},
						},
 
					[4] = {item = "lizard scale boots(2% health extra)",
							itemID = 28123,				
							reqItems = {
								[1] = {item = 6551, count = 100}, -- Boss Dust
								[2] = {item = 6549, count = 100}, -- Dorne Powder
								[3] = {item = 2195, count = 1}, -- boots of haste
								[4] = {item = 2645, count = 1}, -- steel boots
								[5] = {item = 9932, count = 1}, -- firewalker boots
								[6] = {item = 2640, count = 1}, -- pair of soft boots
								[7] = {item = 25412, count = 1}, -- treader of torment
								[8] = {item = 38752, count = 1}, -- hydra boots
								[9] = {item = 38750, count = 1}, -- desert boots
								[10] = {item = 38751, count = 1}, -- celestial boots
								[11] = {item = 38947, count = 1}, -- milk boots
								[12] = {item = 38948, count = 1}, -- red ranger boots
								[13] = {item = 38689, count = 1}, -- pair of soulstalkers
								[14] = {item = 36452, count = 1}, -- winged boots
							},
						},
					},
				},
 
		[4] = {vocation = "Elite Knight", 
				items = {
					[1] = {item = "Retro Magic Longsword",
							itemID = 39168,
							reqItems = {
								[1] = {item = 39718, count = 1}, -- antartida sword
								[2] = {item = 39226, count = 1}, -- saint sword
								[3] = {item = 39225, count = 1}, -- polar sword
								[4] = {item = 39219, count = 1}, -- nightmare sword
								[5] = {item = 38779, count = 1}, -- elf blade
								[6] = {item = 38788, count = 1}, -- quimera blade
								[7] = {item = 38798, count = 1}, -- ice magic sword
								[8] = {item = 38734, count = 1}, -- batwing sword
								[9] = {item = 39218, count = 1}, -- pox sword
								[10] = {item = 39340, count = 1}, -- slime dagger
								[11] = {item = 39370, count = 1}, -- cobra blade
								[12] = {item = 38844, count = 1}, -- red bone dagger
								[13] = {item = 39342, count = 1}, -- hero dagger
								[14] = {item = 39203, count = 1}, -- spike broadsword
								[15] = {item = 39257, count = 1}, -- carmesi sword
								[16] = {item = 39217, count = 1}, -- bloody sword
								[17] = {item = 39202, count = 1}, -- frozen broadsword
								[18] = {item = 39227, count = 1}, -- golden sword
								[19] = {item = 39200, count = 1}, -- heavent sword
								[20] = {item = 39201, count = 1}, -- atomos sword
								[21] = {item = 6551, count = 100}, -- Boss Dust
								[22] = {item = 6549, count = 100}, -- Dorne Powder
							},
						},
 
					[2] = {item = "Retro Great Axe",
							itemID = 39265,		
							reqItems = {
								[1] = {item = 39757, count = 1}, -- darkness axe
								[2] = {item = 39221, count = 1}, -- relic axe
								[3] = {item = 39365, count = 1}, -- falconcutter axe
								[4] = {item = 39224, count = 1}, -- nightmare halberd
								[5] = {item = 39230, count = 1}, -- saint axe
								[6] = {item = 38985, count = 1}, -- crystal axe
								[7] = {item = 39205, count = 1}, -- nightmare axe
								[8] = {item = 39343, count = 1}, -- phoenix axe
								[9] = {item = 38735, count = 1}, -- imperial axe
								[10] = {item = 38782, count = 1}, -- ice axe
								[11] = {item = 38845, count = 1}, -- shark axe
								[12] = {item = 38778, count = 1}, --cyclopmania axe
								[13] = {item = 38783, count = 1}, -- fear axe
								[14] = {item = 39232, count = 1}, -- ancient chopper axe
								[15] = {item = 39229, count = 1}, -- ancient axe
								[16] = {item = 6551, count = 100}, -- Boss Dust
								[17] = {item = 6549, count = 100}, -- Dorne Powder
							},
						},						
 
					[3] = {item = "Retro Skull Staff",
							itemID = 39266,		
							reqItems = {
								[1] = {item = 39758, count = 1}, -- dwarf hammer
								[2] = {item = 38963, count = 1}, -- frost dragon hammer
								[3] = {item = 38960, count = 1}, -- saint hammer
								[4] = {item = 39263, count = 1}, -- Betrayed Hammer
								[5] = {item = 39261, count = 1}, -- Spiky Ice Hammer
								[6] = {item = 38736, count = 1}, -- Demodras Hammer
								[7] = {item = 38841, count = 1}, -- Night Hammer
								[8] = {item = 39375, count = 1}, -- Skeleton Hammer
								[9] = {item = 39345, count = 1}, -- Black Giant Hammer
								[10] = {item = 39351, count = 1}, -- Engel Club
								[11] = {item = 38780, count = 1}, -- Frost Hammer
								[12] = {item = 38794, count = 1}, -- Divine Hammer
								[13] = {item = 6551, count = 100}, -- Boss Dust
								[14] = {item = 6549, count = 100}, -- Dorne Powder
							},
						},
 
					[4] = {item = "black crown legs(3% health extra)",
							itemID = 27919,				
							reqItems = {
								[1] = {item = 6551, count = 100}, -- Boss Dust
								[2] = {item = 6549, count = 100}, -- Dorne Powder
								[3] = {item = 38895, count = 1}, -- supreme legs
								[4] = {item = 38871, count = 1}, -- golden skirt
								[5] = {item = 38770, count = 1}, -- shadow fire legs
								[6] = {item = 38900, count = 1}, -- garden legs
								[7] = {item = 38901, count = 1}, -- black legs
								[8] = {item = 38894, count = 1}, -- skull legs
								[9] = {item = 38896, count = 1}, -- volcanic legs
								[10] = {item = 38833, count = 1}, -- crystal legs
								[11] = {item = 2504, count = 1}, -- dwarven legs
								[12] = {item = 2495, count = 1}, -- demon legs
								[13] = {item = 32420, count = 1}, -- falcon greaves
								[14] = {item = 37452, count = 1}, -- fabulous legs
								[15] = {item = 39170, count = 1}, -- crystalline legs
								[16] = {item = 38899, count = 1}, -- diamond legs
								[17] = {item = 39166, count = 1}, -- golden frieza legs
							},
						},
 
 
 
					[5] = {item = "gay boots(2% health extra)",
							itemID = 28122,				
							reqItems = {
								[1] = {item = 6551, count = 100}, -- Boss Dust
								[2] = {item = 6549, count = 100}, -- Dorne Powder
								[3] = {item = 2195, count = 1}, -- boots of haste
								[4] = {item = 2645, count = 1}, -- steel boots
								[5] = {item = 9932, count = 1}, -- firewalker boots
								[6] = {item = 2640, count = 1}, -- pair of soft boots
								[7] = {item = 25412, count = 1}, -- treader of torment
								[8] = {item = 38752, count = 1}, -- hydra boots
								[9] = {item = 38750, count = 1}, -- desert boots
								[10] = {item = 38751, count = 1}, -- celestial boots
								[11] = {item = 38943, count = 1}, -- industrial boots
								[12] = {item = 38942, count = 1}, -- valen boots
								[13] = {item = 38688, count = 1}, -- pair of soulwalkers
								[14] = {item = 35229, count = 1}, -- cobra boots
							},
						},
					},
				},
			},
		}
 
function onUse(player, item, fromPosition, itemEx, toPosition, isHotkey)
    player:sendMainCraftWindow(config)
    return true
end