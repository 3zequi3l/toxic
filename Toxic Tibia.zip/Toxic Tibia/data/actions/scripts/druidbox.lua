local prize = {
    [1] = {chance = 20, id = 39609, amount = 1 },
    [2] = {chance = 20, id = 39598, amount = 1 },
	[3] = {chance = 20, id = 39797, amount = 1 },
	[4] = {chance = 20, id = 39607, amount = 1 },
	[5] = {chance = 20, id = 39602, amount = 1 },
	[6] = {chance = 20, id = 39606, amount = 1 },
}

function onUse(player, item, fromPosition, target, toPosition, isHotkey)

    for i = 1,#prize do local number = math.random() * 100
    if prize[i].chance>100-number then
        player:getPosition():sendMagicEffect(CONST_ME_POFF)
        player:addItem(prize[i].id, prize[i].amount)
        item:remove()
        break
    end
    end
    return true
end
