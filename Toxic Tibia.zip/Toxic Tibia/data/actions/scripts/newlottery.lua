local decayItems = {
	[1945] = 1946, [1946] = 1945
}
local slots = {
	-- aqui sao os slots da esteira, por onde os itens vao ir passando... podem ser adicionados quantos quiser...
	Position(123, 162, 7), Position(124, 162, 7), Position(125, 162, 7), Position(126, 162, 7),	Position(127, 162, 7),
	Position(128, 162, 7), Position(129, 162, 7), Position(130, 162, 7), Position(131, 162, 7),	Position(132, 162, 7),
	Position(133, 162, 7), Position(134, 162, 7), Position(135, 162, 7)
}

local itemtable = {
	--aqui pode ter ate 100 itens.. a chance nunca pode se repetir, ela deve ser de 1 a 100...
	-- inserir os itens respeitando a ordem: [1], [2], [3], ...  ate o ultimo [100]
	[1] = {id = 2148, chance = 1},
	[2] = {id = 2398, chance = 5},
	[3] = {id = 2386, chance = 10},
	[4] = {id = 2643, chance = 15},
	[5] = {id = 2461, chance = 20},
	[6] = {id = 2510, chance = 25},
	[7] = {id = 2649, chance = 30},
	[8] = {id = 2643, chance = 35},
	[9] = {id = 2647, chance = 40},
	[10] = {id = 9078, chance = 45},
	[11] = {id = 2490, chance = 50},
	[12] = {id = 2457, chance = 55},
	[13] = {id = 2152, chance = 60},
	
	
	
	[14] = {id = 38686, chance = 99},
	[15] = {id = 38687, chance = 99},
	[16] = {id = 38685, chance = 98},
	[17] = {id = 38680, chance = 97},
	[18] = {id = 38676, chance = 96},
	[19] = {id = 38682, chance = 95},
	[20] = {id = 38681, chance = 94},
	[21] = {id = 38673, chance = 93},
	[22] = {id = 38677, chance = 92},
	[23] = {id = 38690, chance = 92},
	
	[24] = {id = 25411, chance = 91},
	[25] = {id = 25415, chance = 89},
	[26] = {id = 25410, chance = 88},
	[27] = {id = 25412, chance = 87},
	[28] = {id = 25414, chance = 86},
	[29] = {id = 38718, chance = 85},
	
	
	[30] = {id = 38715, chance = 84},
	[31] = {id = 38717, chance = 83},
	[32] = {id = 38719, chance = 82},
	[33] = {id = 38711, chance = 81},
	[34] = {id = 38716, chance = 81},
	[35] = {id = 38732, chance = 80},
	
	
	[36] = {id = 35234, chance = 79},
	[37] = {id = 35229, chance = 78},
	[38] = {id = 35230, chance = 77},
	[39] = {id = 35228, chance = 76},
	[40] = {id = 35231, chance = 75},
	[41] = {id = 35232, chance = 74},
	[42] = {id = 35235, chance = 73},
	
	
	
	[36] = {id = 32422, chance = 72},
	[37] = {id = 32423, chance = 71},
	[38] = {id = 32415, chance = 70},
	[39] = {id = 32419, chance = 69},
	[40] = {id = 32424, chance = 68},
	[41] = {id = 32418, chance = 67},
	[42] = {id = 32420, chance = 66},
	[40] = {id = 32414, chance = 65},
	[41] = {id = 32425, chance = 64},
	[42] = {id = 32417, chance = 63},
	
	
	
	[43] = {id = 2160, chance = 61},
	[44] = {id = 2159, chance = 62}
}

local function ender(cid, position)
	local player = Player(cid)
	local posicaofim = Position(129, 162, 7) -- AQUI VAI APARECER A SETA, que define o item que o player ganhou
	local item = Tile(posicaofim):getTopDownItem()
	if item then
		local itemId = item:getId()
		posicaofim:sendMagicEffect(CONST_ME_TUTORIALARROW)
		player:addItem(itemId, 1)
	end
	local alavanca = Tile(position):getTopDownItem()
	if alavanca then
		alavanca:setActionId(18562) -- aqui volta o actionid antigo, para permitir uma proxima jogada...
	end
	if itemId == 2159 or itemId == 2160 then --checar se é o ID do item LENDARIO
		broadcastMessage("O player "..player:getName().." ganhou "..item:getName().."", MESSAGE_EVENT_ADVANCE) -- se for item raro mandar no broadcast
		
		for _, pid in ipairs(getPlayersOnline()) do
			if pid ~= cid then
				pid:say("O player "..player:getName().." ganhou "..item:getName().."", TALKTYPE_MONSTER_SAY) -- se nao for lendario, mandar uma mensagem comum
			end
		end
	end
end

local function delay(position, aux)
	local item = Tile(position):getTopDownItem()
	if item then
		local slot = aux + 1
		item:moveTo(slots[slot])
	end	
end

local function exec(cid)
	--calcular uma chance e atribuir um item
	local rand = math.random(1, 100)
	local aux, memo = 0, 0
	if rand >= 1 then
		for i = 1, #itemtable do
			local randitemid = itemtable[i].id
			local randitemchance = itemtable[i].chance
			if rand >= randitemchance then
				aux = aux + 1
				memo = randitemchance
			end
			
		end
	end
	-- Passo um: Criar um item no primeiro SLOT, e deletar se houver o item do ultimo slot.
	Game.createItem(itemtable[aux].id, 1, slots[1])
	slots[1]:sendMagicEffect(CONST_ME_POFF)
	local item = Tile(slots[#slots]):getTopDownItem()
	if item then
		item:remove()
	end
	--Passo dois: Mover itens para o proximo slot em todos os slots de 1 a 12 para o 2 > 13
	local maxslot = #slots-1
	local lastloop = 0
	for i = 1, maxslot do
		
		addEvent(delay, 1*1*60, slots[i], i)
	end
end

function onUse(cid, item, fromPosition, itemEx, toPosition)
	local player = Player(cid)
	if not player then
		return false
	end
	if not player:removeItem(5091, 1) then -- PARA JOGAR o player precisa ter o item 5091, que representa um bilhete vendido na store ou em um npc....
		return false
	end
	
	item:transform(decayItems[item.itemid])
	item:decay()	
	--muda actionid do item para nao permitir executar duas instancias
	item:setActionId(18563)
	
	local segundos = 30
	local loopsize = segundos*2
	
	for i = 1, loopsize do
		addEvent(exec, 1*i*500, cid.uid)
	end
	addEvent(ender, (1*loopsize*500)+1000, cid.uid, fromPosition)
	
	return true
end
