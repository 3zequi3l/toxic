        
		local function removePet(creatureId)
            local c = Creature(creatureId)
            if not c then return false end

            c:remove()
        end


    
	  
	  
	    function onUse(player, item, fromPosition, target, toPosition, isHotkey)
        
        if not player then return false end
	  
        
     
            

            if #player:getSummons() >= 1 then
                player:sendCancelMessage("You can't have other summons.")
                player:getPosition():sendMagicEffect(CONST_ME_POFF)
               return false
            end

            vocationId = player:getVocation():getId()
            summonName = nil
            if vocationId == 1 or vocationId == 5 then
                summonName = "gai gates"
            elseif vocationId == 2 or vocationId == 6 then
                summonName = "gai gates"
            elseif vocationId == 3 or vocationId == 7 then
                summonName = "gai gates"
            elseif vocationId == 4 or vocationId == 8 then
                summonName = "gai gates"
            end
            
            if not summonName then return false end

            local mySummon = Game.createMonster(summonName, player:getPosition(), true, true)
            if not mySummon then
                return player:sendCancelMessage("not.")
            end
            
           
            player:addSummon(mySummon)
            player:say("gai gates hora de pelear!", TALKTYPE_MONSTER_SAY)
            addEvent(removePet, 15*60*1000, mySummon:getId())
			
   
        return true
    end
       