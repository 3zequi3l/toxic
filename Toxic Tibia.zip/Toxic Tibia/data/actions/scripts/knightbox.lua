local prize = {
    [1] = {chance = 20, id = 39706, amount = 1 },
    [2] = {chance = 20, id = 39321, amount = 1 },
	[3] = {chance = 20, id = 39320, amount = 1 },
	[4] = {chance = 20, id = 39731, amount = 1 },
	[5] = {chance = 20, id = 39318, amount = 1 },
	[6] = {chance = 20, id = 39319, amount = 1 },
	[7] = {chance = 20, id = 39755, amount = 1 },
    [8] = {chance = 20, id = 39741, amount = 1 },
}

function onUse(player, item, fromPosition, target, toPosition, isHotkey)

    for i = 1,#prize do local number = math.random() * 100
    if prize[i].chance>100-number then
        player:getPosition():sendMagicEffect(CONST_ME_POFF)
        player:addItem(prize[i].id, prize[i].amount)
        item:remove()
        break
    end
    end
    return true
end
