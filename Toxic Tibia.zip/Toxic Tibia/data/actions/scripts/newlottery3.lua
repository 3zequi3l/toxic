local decayItems = {
	[1945] = 1946, [1946] = 1945
}
local slots = {
	-- aqui sao os slots da esteira, por onde os itens vao ir passando... podem ser adicionados quantos quiser...
	Position(94, 188, 7), Position(95, 188, 7), Position(96, 188, 7), Position(97, 188, 7),	Position(98, 188, 7),
	Position(99, 188, 7), Position(100, 188, 7), Position(101, 188, 7), Position(102, 188, 7)
}

local itemtable = {
	--aqui pode ter ate 100 itens.. a chance nunca pode se repetir, ela deve ser de 1 a 100...
	-- inserir os itens respeitando a ordem: [1], [2], [3], ...  ate o ultimo [100]
	[1] = {id = 2148, chance = 1},
	[2] = {id = 2398, chance = 5},
	[3] = {id = 2386, chance = 10},
	[4] = {id = 2643, chance = 15},
	[5] = {id = 2461, chance = 20},
	[6] = {id = 2510, chance = 25},
	[7] = {id = 2649, chance = 26},
	[8] = {id = 2643, chance = 27},
	[9] = {id = 2647, chance = 28},
	[10] = {id = 9078, chance = 29},
	[11] = {id = 2490, chance = 30},
	[12] = {id = 2457, chance = 31},
	[13] = {id = 2152, chance = 32},
	[14] = {id = 2160, chance = 33},
	[15] = {id = 2159, chance = 34},
	
	
	
	[16] = {id = 38736, chance = 60},
	[17] = {id = 38832, chance = 61},
	[18] = {id = 38900, chance = 62},
	[19] = {id = 38880, chance = 63},
	[20] = {id = 38856, chance = 64},
	[21] = {id = 38901, chance = 65},
	[22] = {id = 38837, chance = 66},
	[23] = {id = 38841, chance = 67},
	[24] = {id = 38779, chance = 68},
	[25] = {id = 38768, chance = 69},
	[26] = {id = 38742, chance = 70},
	[27] = {id = 38744, chance = 71},
	[28] = {id = 38883, chance = 72},
	[29] = {id = 38853, chance = 73},
	
	[30] = {id = 38794, chance = 74},
	[31] = {id = 38826, chance = 75},
	[32] = {id = 38811, chance = 76},
	[33] = {id = 38763, chance = 77},
	[34] = {id = 38767, chance = 78},
	[35] = {id = 38783, chance = 79},
	[36] = {id = 38894, chance = 80},
	[37] = {id = 38851, chance = 81},
	[38] = {id = 38833, chance = 82},
	[39] = {id = 38862, chance = 83},
	[40] = {id = 38756, chance = 84},
	[41] = {id = 38746, chance = 85},
	[42] = {id = 38839, chance = 86},
	[43] = {id = 38896, chance = 87},
	
	
	[44] = {id = 38827, chance = 88},
	[45] = {id = 38761, chance = 89},
	[46] = {id = 38781, chance = 90},
	[47] = {id = 38745, chance = 91},
	[48] = {id = 38770, chance = 92},
	[49] = {id = 38788, chance = 93},
	[50] = {id = 38828, chance = 94},
	[51] = {id = 38885, chance = 95},
	[52] = {id = 38786, chance = 96},
	[53] = {id = 38780, chance = 97},
	[54] = {id = 38846, chance = 98},
	[55] = {id = 38776, chance = 99},
	[56] = {id = 38845, chance = 99},
	[57] = {id = 38830, chance = 99},
	
	
	
	[58] = {id = 38887, chance = 99},
	[59] = {id = 38895, chance = 99},
	[60] = {id = 38858, chance = 99},
	[61] = {id = 38871, chance = 99},
	[62] = {id = 38865, chance = 99},
	[63] = {id = 38867, chance = 99},
	[64] = {id = 38874, chance = 99},
	[65] = {id = 38778, chance = 99},
	[66] = {id = 38855, chance = 99},
	[67] = {id = 38864, chance = 99},
	[68] = {id = 38765, chance = 99},
	[69] = {id = 38847, chance = 99},
	[70] = {id = 38754, chance = 99},
	[71] = {id = 38762, chance = 99},
	[72] = {id = 38734, chance = 99},
	[73] = {id = 38750, chance = 99},
	[74] = {id = 38766, chance = 99},
	[75] = {id = 38825, chance = 99},
	[76] = {id = 38879, chance = 99},
	[77] = {id = 38787, chance = 99},
	[78] = {id = 38877, chance = 99},
	[79] = {id = 38876, chance = 99},
	
	[80] = {id = 38869, chance = 99},
	[81] = {id = 38870, chance = 99},
	[82] = {id = 38868, chance = 99},
	[83] = {id = 38842, chance = 99},
	[84] = {id = 38840, chance = 99},
	[85] = {id = 38764, chance = 99},
	[86] = {id = 38760, chance = 99},
	[87] = {id = 38753, chance = 99},
	[88] = {id = 38777, chance = 99},
	[89] = {id = 38759, chance = 99},
	[90] = {id = 38782, chance = 99},
	[91] = {id = 38755, chance = 99},
	[92] = {id = 38752, chance = 99},
	[93] = {id = 38751, chance = 99},
	[94] = {id = 38735, chance = 99},
	[95] = {id = 38741, chance = 99},
	[96] = {id = 38792, chance = 99},
	[97] = {id = 38791, chance = 99},
	[98] = {id = 38798, chance = 99},
	[99] = {id = 38789, chance = 99},
	[100] = {id = 38784, chance = 99}
	
	
	
}

local function ender(cid, position)
	local player = Player(cid)
	local posicaofim = Position(98, 188, 7) -- AQUI VAI APARECER A SETA, que define o item que o player ganhou
	local item = Tile(posicaofim):getTopDownItem()
	if item then
		local itemId = item:getId()
		posicaofim:sendMagicEffect(CONST_ME_TUTORIALARROW)
		player:addItem(itemId, 1)
	end
	local alavanca = Tile(position):getTopDownItem()
	if alavanca then
		alavanca:setActionId(18566) -- aqui volta o actionid antigo, para permitir uma proxima jogada...
	end
	if itemId == 2159 or itemId == 2160 then --checar se é o ID do item LENDARIO
		broadcastMessage("O player "..player:getName().." ganhou "..item:getName().."", MESSAGE_EVENT_ADVANCE) -- se for item raro mandar no broadcast
		
		for _, pid in ipairs(getPlayersOnline()) do
			if pid ~= cid then
				pid:say("O player "..player:getName().." ganhou "..item:getName().."", TALKTYPE_MONSTER_SAY) -- se nao for lendario, mandar uma mensagem comum
			end
		end
	end
end

local function delay(position, aux)
	local item = Tile(position):getTopDownItem()
	if item then
		local slot = aux + 1
		item:moveTo(slots[slot])
	end	
end

local function exec(cid)
	--calcular uma chance e atribuir um item
	local rand = math.random(1, 100)
	local aux, memo = 0, 0
	if rand >= 1 then
		for i = 1, #itemtable do
			local randitemid = itemtable[i].id
			local randitemchance = itemtable[i].chance
			if rand >= randitemchance then
				aux = aux + 1
				memo = randitemchance
			end
			
		end
	end
	-- Passo um: Criar um item no primeiro SLOT, e deletar se houver o item do ultimo slot.
	Game.createItem(itemtable[aux].id, 1, slots[1])
	slots[1]:sendMagicEffect(CONST_ME_POFF)
	local item = Tile(slots[#slots]):getTopDownItem()
	if item then
		item:remove()
	end
	--Passo dois: Mover itens para o proximo slot em todos os slots de 1 a 12 para o 2 > 13
	local maxslot = #slots-1
	local lastloop = 0
	for i = 1, maxslot do
		
		addEvent(delay, 1*1*60, slots[i], i)
	end
end

function onUse(cid, item, fromPosition, itemEx, toPosition)
	local player = Player(cid)
	if not player then
		return false
	end
	if not player:removeItem(8981, 1) then -- PARA JOGAR o player precisa ter o item 5091, que representa um bilhete vendido na store ou em um npc....
		return false
	end
	
	item:transform(decayItems[item.itemid])
	item:decay()	
	--muda actionid do item para nao permitir executar duas instancias
	item:setActionId(18567)
	
	local segundos = 30
	local loopsize = segundos*2
	
	for i = 1, loopsize do
		addEvent(exec, 1*i*500, cid.uid)
	end
	addEvent(ender, (1*loopsize*500)+1000, cid.uid, fromPosition)
	
	return true
end
