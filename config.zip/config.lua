spoofDailyMinPlayers = 10
spoofDailyMaxPlayers = 50
spoofNoiseInterval = 10 * 60 * 1000
spoofNoise = 10
spoofTimezone = -3
spoofInterval = 60 * 1000
spoofChangeChance = 100
spoofIncrementChange = 5
spoofEnabled = false


worldType = "pvp"
hotkeyAimbotEnabled = true
protectionLevel = 100
pzLocked = 30 * 1000
removeChargesFromRunes = false
removeChargesFromPotions = true
removeWeaponAmmunition = false
removeWeaponCharges = false
timeToDecreaseFrags = 1 * 24 * 60 * 60
whiteSkullTime = 2 * 60 * 1000
stairJumpExhaustion = 2 * 1000
experienceByKillingPlayers = true
expFromPlayersLevelRange = 75
dayKillsToRedSkull = 15
weekKillsToRedSkull = 30
monthKillsToRedSkull = 90
redSkullDuration = 1
blackSkullDuration = 1
orangeSkullDuration = 1

onlyInvitedCanMoveHouseItems = true
cleanProtectionZones = true

ip = "harderarpg.com"
bindOnlyGlobalAddress = false
loginProtocolPort = 7171
gameProtocolPort = 7172
statusProtocolPort = 7171
maxPlayers = 0
motd = "Welcome to HarderaRPG - UPDATE 2023"
onePlayerOnlinePerAccount = false
allowClones = false
serverName = "Hardera Real"
statusTimeout = 5 * 1000
replaceKickOnLogin = true
maxPacketsPerSecond = 125
maxItem = 2000
maxContainer = 100
encryptionType = "sha1"
passwordType = "sha1"

clientVersion = 1291
clientVersionStr = "12.91"
allowClientOld = true

freeDepotLimit = 2000
premiumDepotLimit = 10000
depotBoxes = 18

gamestoreByModules = true

onlyPremiumAccount = false

weatherRain = false
thunderEffect = false
freeQuests = true
allConsoleLog = false

deathLosePercent = -1

housePriceEachSQM = 10000
houseRentPeriod = "never"
houseOwnedByAccount = false

timeBetweenActions = 200
timeBetweenExActions = 1000

pushDelay = 500
pushDistanceDelay = 1000

marketActionsWithStash = false

mapName = "otservbrold"
mapAuthor = "Concept"

mapCustomName = "otservbr-custom"
mapCustomFile = "data/world/custom/otservbr-custom.otbm"
mapCustomSpawn = "data/world/custom/otservbr-custom-spawn.xml"
mapCustomAuthor = "OTServBR"
mapCustomEnabled = false


marketOfferDuration = 30 * 24 * 60 * 60
premiumToCreateMarketOffer = false
checkExpiredMarketOffersEachMinutes = 60
maxMarketOffersAtATimePerPlayer = 100

mysqlHost = "127.0.0.1"
mysqlUser = "XXXXX"
mysqlPass = "XXXXX"
mysqlDatabase = "XXXXX"
mysqlPort = 3306
mysqlSock = ""
encryptionType = "sha1"
passwordType = "sha1" 

allowChangeOutfit = true
freePremium = true
kickIdlePlayerAfterMinutes = false
maxMessageBuffer = 5
emoteSpells = true
classicEquipmentSlots = false
allowWalkthrough = true
coinPacketSize = 5
coinImagesURL = "http://harderarpg.com/images/store/"                                                                                          
classicAttackSpeed = false
showScriptsLogInConsole = false

maxAllowedOnADummy = 4

serverSaveNotifyMessage = true
serverSaveNotifyDuration = 5
serverSaveCleanMap = true
serverSaveClose = true
serverSaveShutdown = true

rateExp = 2
rateSkill = 2
rateLoot = 1
rateMagic = 2
rateSpawn = 1.5

rateMonsterHealth = 2.0
rateMonsterAttack = 2.6
rateMonsterDefense = 3.5

deSpawnRange = 2
deSpawnRadius = 50

staminaSystem = true

warnUnsafeScripts = true
convertUnsafeScripts = true

defaultPriority = "normal"
startupDatabaseOptimization = true

ownerName = "Ezequiel Gonzalez"
ownerEmail = "harderareal.tk@gmail.com"
url = "harderarpg.com"
location = "Mexico"

discordWebhookURL = ""
