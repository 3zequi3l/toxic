# Concept OT Server 12.72 Protocol

## Compile Guide

### Ubuntu 20 x86-x64

```
sudo apt update
sudo apt-get dist-upgrade
sudo apt-get install git cmake build-essential libluajit-5.1-dev ca-certificates curl zip unzip tar pkg-config
sudo git clone https://github.com/microsoft/vcpkg
cd vcpkg
./bootstrap-vcpkg.sh -disableMetrics
cd ../
cd conceptot-source
rm -rf build/
mkdir build && cd build
cmake -DCMAKE_TOOLCHAIN_FILE=../../vcpkg/scripts/buildsystems/vcpkg.cmake ..
make -j`nproc`
```

### Ubuntu 20 arm64

```
wget https://github.com/Kitware/CMake/releases/download/v3.23.0-rc2/cmake-3.23.0-rc2-linux-aarch64.sh
mv cmake-3.23.0-rc2-linux-aarch64.sh /opt/cmake-3.23.0-rc2-linux-aarch64.sh
cd /opt/ && sudo bash cmake-3.23.0-rc2-linux-aarch64.sh
Y PARA ACEITAR OS TERMOS

nano ~/.bashrc
ADICIONAR NA ULTIMA LINHA:
export PATH=$PATH:/opt/cmake-3.23.0-rc2-linux-aarch64/bin
SALVAR E SAIR: CTRL + O e CTRL + X
source ~/.bashrc

nano ~/.bashrc
ADICIONAR NA ULTIMA LINHA:
export export VCPKG_FORCE_SYSTEM_BINARIES=1
SALVAR E SAIR: CTRL + O e CTRL + X
source ~/.bashrc

sudo apt-get dist-upgrade
sudo apt-get install git build-essential libluajit-5.1-dev ca-certificates curl zip unzip tar pkg-config ninja-build
sudo su root
sudo git clone https://github.com/microsoft/vcpkg
cd vcpkg
./bootstrap-vcpkg.sh
cd ../
cd /conceptot-source
rm -rf build/
mkdir build && cd build
cmake -DCMAKE_TOOLCHAIN_FILE=../../vcpkg/scripts/buildsystems/vcpkg.cmake ..
make -j`nproc`
```
