#!/bin/bash
ulimit -c unlimited
while true; 
do
TEMPO="$(date +'%d-%m-%Y-%H-%M')"
./tfs | tee "serverlog_____"$TEMPO".log"; done