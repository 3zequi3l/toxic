local mType = Game.createMonsterType("Blood Necrolord")
local monster = {}

monster.description = "a blood necrolord"
monster.experience = 4200
monster.outfit = {
	lookType = 145,
	lookHead = 94,
	lookBody = 94,
	lookLegs = 0,
	lookFeet = 115,
	lookAddons = 3,
	lookMount = 0
}

monster.health = 3980
monster.maxHealth = 3980
monster.race = "blood"
monster.corpse = 6080
monster.speed = 220
monster.manaCost = 0
monster.maxSummons = 0

monster.changeTarget = {
	interval = 4000,
	chance = 10
}

monster.strategiesTarget = {
	nearest = 80,
	health = 10,
	damage = 10,
}

monster.flags = {
	summonable = false,
	attackable = true,
	hostile = true,
	convinceable = false,
	pushable = false,
	rewardBoss = false,
	illusionable = false,
	canPushItems = true,
	canPushCreatures = true,
	staticAttackChance = 90,
	targetDistance = 1,
	runHealth = 0,
	healthHidden = false,
	isBlockable = true,
	canWalkOnEnergy = true,
	canWalkOnFire = true,
	canWalkOnPoison = true,
	pet = false
}

monster.light = {
	level = 0,
	color = 0
}

monster.loot = {
    {id = 2148, maxCount = 100, chance = 100000},-- gold -->
    {id = 2148, maxCount = 60, chance = 100000}, -- gold -->
    {id = 2148, maxCount = 40, chance = 100000}, -- gold -->
    {id = 7590, maxCount = 1, chance = 100000}, -- great mana potion -->
    {id = 8901, chance = 2500},-- spellbook -->
    {id = 7456, chance = 2500},-- noble axe -->
    {id = 11240, chance = 1500},-- guardian boots -->
        {id = 2796, maxCount = 1, chance = 1500},
        {id = 2229, maxCount = 3, chance = 20000},
        {id = 2436, chance = 2833},
        {id = 2663, chance = 2009},
        {id = 13291, chance = 2000},-- --maxila maximus undead cavebear mount -->
        {id = 11237, chance = 2500},-- necro book -->
        {id = 8910, chance = 2500},-- underworld rod -->
        {id = 5909, maxCount = 1, chance = 5000}, -- white piece -->
        {id = 5911, maxCount = 1, chance = 5000}, -- red piece -->
        {id = 10556, maxCount = 1, chance = 5000}, -- cultish robe -->
        {id = 2195, chance = 1366},-- BOH -->
        {id = 2423, chance = 4000},-- clerical mace -->
        {id = 21247, chance = 4000},-- pieces of magical chalk -->
        {id = 5669, chance = 2500},-- voodoo skull -->
}

monster.attacks = {
	{name ="melee", interval = 2000, chance = 100, skill = 70, attack = 70},
	{name ="combat", interval = 2000, chance = 10, type = COMBAT_MANADRAIN, minDamage = 0, maxDamage = -120, range = 7, target = false},
	{name ="combat", interval = 2000, chance = 40, type = COMBAT_DEATHDAMAGE, minDamage = 0, maxDamage = -265, range = 7, shootEffect = CONST_ANI_SUDDENDEATH, effect = CONST_ME_MORTAREA, target = false},
	{name ="combat", interval = 2000, chance = 10, type = COMBAT_EARTHAMAGE, minDamage = -50, maxDamage = -320, length = 8, spread = 3, effect = CONST_ME_POISON, target = false},
	{name ="combat", interval = 2000, chance = 15, type = COMBAT_DEATHDAMAGE, minDamage = -20, maxDamage = -500, length = 7, spread = 3, effect = CONST_ME_SMALLCLOUDS, target = false},
	{name ="combat", interval = 2000, chance = 10, type = COMBAT_DEATHDAMAGE, minDamage = -225, maxDamage = -575, radius = 3, effect = CONST_ME_MORTAREA, target = false},
	{name ="combat", interval = 2000, chance = 10, type = COMBAT_DEATHDAMAGE, minDamage = -225, maxDamage = -575, radius = 3,  effect = CONST_ME_POISON, target = false},
	{name ="condition", type = CONDITION_CURSED, interval = 2000, chance = 10, minDamage = -300, maxDamage = -400, radius = 2, effect = CONST_ME_MORTAREA, target = false},
}

monster.defenses = {
	defense = 40,
	armor = 40,
	{name ="combat", interval = 2000, chance = 20, type = COMBAT_HEALING, minDamage = 80, maxDamage = 150, effect = CONST_ME_MAGIC_BLUE, target = false}
}

monster.elements = {
	{type = COMBAT_PHYSICALDAMAGE, percent = -5},
	{type = COMBAT_ENERGYDAMAGE, percent = 5},
	{type = COMBAT_EARTHDAMAGE, percent = 5},
	{type = COMBAT_FIREDAMAGE, percent = 5},
	{type = COMBAT_LIFEDRAIN, percent = 0},
	{type = COMBAT_MANADRAIN, percent = 0},
	{type = COMBAT_DROWNDAMAGE, percent = 0},
	{type = COMBAT_ICEDAMAGE, percent = 0},
	{type = COMBAT_HOLYDAMAGE , percent = -10},
	{type = COMBAT_DEATHDAMAGE , percent = 5}
}

monster.immunities = {
	{type = "paralyze", condition = true},
	{type = "outfit", condition = true},
	{type = "invisible", condition = true},
	{type = "bleed", condition = false}
}

mType:register(monster)
