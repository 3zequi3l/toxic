local mType = Game.createMonsterType("Goshnar's Spite")

local monster = {}



monster.description = "an goshnar's spite"

monster.experience = 800

monster.outfit = {

	lookType = 1305,

	lookHead = 0,

	lookBody = 0,

	lookLegs = 0,

	lookFeet = 0,

	lookAddons = 0,

	lookMount = 0

}



monster.raceId = 508



monster.events = {

    "spitedeath"

}



monster.health = 500000

monster.maxHealth = 500000

monster.race = "undead"

monster.corpse = 38702

monster.speed = 340

monster.manaCost = 0

monster.maxSummons = 7



monster.changeTarget = {

	interval = 4000,

	chance = 1000

}



monster.strategiesTarget = {

	nearest = 100,

}



monster.flags = {

	summonable = false,

	attackable = true,

	hostile = true,

	convinceable = false,

	pushable = false,

	rewardBoss = true,

	illusionable = false,

	canPushItems = true,

	canPushCreatures = true,

	staticAttackChance = 100,

	targetDistance = 3,

	runHealth = 0,

	healthHidden = false,

	isBlockable = false,

	canWalkOnEnergy = false,

	canWalkOnFire = false,

	canWalkOnPoison = false,

	pet = false

}



monster.light = {

	level = 0,

	color = 0

}



monster.summons = {

	{name = "Dreadful Harvester", chance = 100, interval = 2000},

	{name = "Dreadful Harvester", chance = 100, interval = 2000},

	{name = "Dreadful Harvester", chance = 100, interval = 2000},

	{name = "Dreadful Harvester", chance = 100, interval = 2000}

}





monster.voices = {

	interval = 5000,

	chance = 0,

	{text = "Let's battle it out in a duel!", yell = false},

	{text = "Bring it!", yell = false},

	{text = "I'll fight here in eternity and beyond.", yell = false},

	{text = "I will not give up!", yell = false},

	{text = "Another foolish adventurer who tries to beat me.", yell = false}

}



monster.loot = {

	{name = "gold coin", chance = 44000, maxCount = 100},

	{name = "gold coin", chance = 50500, maxCount = 48},

	{name = "berserk potion", chance = 2850},

	{name = "bullseye potion", chance = 2850},

	{name = "mastermind potion", chance = 2850},

	{name = "blue gem", chance = 2850},

	{name = "dragon figurine", chance = 2850},

	{name = "giant sapphire", chance = 2850},

	{name = "giant topaz", chance = 2850},

	{name = "green gem", chance = 2850},

	{name = "red gem", chance = 2850},

	{name = "violet gem", chance = 2850},

	{name = "white gem", chance = 2850},

	{name = "yellow gem", chance = 2850},

	{name = "malice's spine", chance = 850},

	{name = "the skull of a beast", chance = 850},

	{name = "bag you desire", chance = 9}	

}



monster.attacks = {

	{name ="melee", interval = 2000, chance = 5, minDamage = -3000, maxDamage = -5000},

	{name ="combat", interval = 2000, chance = 20, type = COMBAT_PHYSICALDAMAGE, minDamage = -1500, maxDamage = -2500, range = 7, shootEffect = CONST_ANI_WHIRLWINDSWORD, target = false},

	{name ="combat", interval = 2000, chance = 30, type = COMBAT_DEATHDAMAGE, minDamage = -500, maxDamage = -2000, range = 7, radius = 9, shootEffect = CONST_ANI_SUDDENDEATH, effect = CONST_ME_MORTAREA, target = false},

}





monster.defenses = {

	defense = 70,

	armor = 70,

	{name ="combat", interval = 3000, chance = 35, type = COMBAT_HEALING, minDamage = 2500, maxDamage = 3500, effect = CONST_ME_MAGIC_BLUE, target = false},

	{name ="speed", interval = 4000, chance = 80, speedChange = 700, effect = CONST_ME_MAGIC_RED, target = false, duration = 6000}



}



monster.elements = {

	{type = COMBAT_PHYSICALDAMAGE, percent = 50},

	{type = COMBAT_ENERGYDAMAGE, percent = 50},

	{type = COMBAT_EARTHDAMAGE, percent = 50},

	{type = COMBAT_FIREDAMAGE, percent = 50},

	{type = COMBAT_LIFEDRAIN, percent = 50},

	{type = COMBAT_MANADRAIN, percent = 50},

	{type = COMBAT_DROWNDAMAGE, percent = 50},

	{type = COMBAT_ICEDAMAGE, percent = 50},

	{type = COMBAT_HOLYDAMAGE , percent = 50},

	{type = COMBAT_DEATHDAMAGE , percent = 50}

}



monster.immunities = {

	{type = "paralyze", condition = false},

	{type = "outfit", condition = false},

	{type = "invisible", condition = true},

	{type = "bleed", condition = false}

}



mType.onAppear = function(monster, creature)

	if monster:getType():isRewardBoss() then

		monster:setReward(true)

	end

end



mType:register(monster)

