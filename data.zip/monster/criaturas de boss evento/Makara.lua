local mType = Game.createMonsterType("Makara")
local monster = {}

monster.description = "a Makara"
monster.experience = 6150
monster.outfit = {
	lookType = 1565,
	lookHead = 94,
	lookBody = 94,
	lookLegs = 94,
	lookFeet = 88,
	lookAddons = 0,
	lookMount = 0
}

monster.health = 4770
monster.maxHealth = 4770
monster.race = "blood"
monster.corpse = 44201
monster.speed = 250
monster.manaCost = 0
monster.maxSummons = 0

monster.changeTarget = {
	interval = 4000,
	chance = 10
}

monster.strategiesTarget = {
	nearest = 70,
	health = 10,
	damage = 10,
	random = 10,
}

monster.flags = {
	summonable = false,
	attackable = true,
	hostile = true,
	convinceable = false,
	pushable = false,
	rewardBoss = false,
	illusionable = true,
	canPushItems = true,
	canPushCreatures = true,
	staticAttackChance = 70,
	targetDistance = 1,
	runHealth = 50,
	healthHidden = false,
	isBlockable = false,
	canWalkOnEnergy = false,
	canWalkOnFire = false,
	canWalkOnPoison = false,
	pet = false
}

monster.light = {
	level = 0,
	color = 0
}

monster.voices = {
	interval = 5000,
	chance = 10,
	{text = "Gimme! Gimme!", yell = false}
}

monster.loot = {

	{name = "platinum coin", chance = 47500, maxCount = 6},
	{name = "Makara Fin", chance = 8500},
	{name = "Makara Tongue", chance = 9500},
	{name = "sea horse figurine", chance = 6500},
	{name = "small diamond", chance = 17500, maxCount = 3},
	{name = "yellow gem", chance = 16500, maxCount = 3},
	{name = "blue gem", chance = 15500, maxCount = 3},
	{name = "green crystal shard", chance = 14500, maxCount = 3},
	{name = "cyan crystal fragment", chance = 13500, maxCount = 3},
	{name = "green crystal fragment", chance = 12500, maxCount = 3},
	{name = "rainbow quartz", chance = 11500, maxCount = 3}

}

monster.attacks = {
	{name ="melee", interval = 2000, chance = 100, minDamage = 100, maxDamage = -140},
	{name ="combat", interval = 1500, chance = 30, type = COMBAT_PHYSICALDAMAGE, minDamage = -190, maxDamage = -250, shootEffect = CONST_ANI_CAKE, range = 5, radius = 1, effect = CONST_ME_WATERSPLASH, target = true},
	{name ="combat", interval = 1800, chance = 15, type = COMBAT_PHYSICALDAMAGE, minDamage = -200, maxDamage = -300, length = 4, spread = 3, effect = CONST_ME_WATERSPLASH, target = false}
}

monster.defenses = {
	defense = 45,
	armor = 45,
	{name ="combat", interval = 2000, chance = 10, type = COMBAT_HEALING, minDamage = 30, maxDamage = 60, effect = CONST_ME_MAGIC_BLUE, target = false}
}

monster.elements = {
	{type = COMBAT_PHYSICALDAMAGE, percent = 0},
	{type = COMBAT_ENERGYDAMAGE, percent = 20},
	{type = COMBAT_EARTHDAMAGE, percent = 0},
	{type = COMBAT_FIREDAMAGE, percent = 0},
	{type = COMBAT_LIFEDRAIN, percent = 0},
	{type = COMBAT_MANADRAIN, percent = 0},
	{type = COMBAT_DROWNDAMAGE, percent = 0},
	{type = COMBAT_ICEDAMAGE, percent = 20},
	{type = COMBAT_HOLYDAMAGE , percent = 0},
	{type = COMBAT_DEATHDAMAGE , percent = 0}
}

monster.immunities = {
	{type = "paralyze", condition = true},
	{type = "outfit", condition = false},
	{type = "invisible", condition = true},
	{type = "bleed", condition = false}
}

mType:register(monster)
