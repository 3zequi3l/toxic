local mType = Game.createMonsterType("Naga Archer")
local monster = {}

monster.description = "a Naga Archer"
monster.experience = 9520
monster.outfit = {
	lookType = 1537,
	lookHead = 75,
	lookBody = 46,
	lookLegs = 19,
	lookFeet = 78,
	lookAddons = 3,
	lookMount = 0
}

monster.health = 7460
monster.maxHealth = 7460
monster.race = "blood"
monster.corpse = 44060
monster.speed = 282
monster.manaCost = 0
monster.maxSummons = 0

monster.changeTarget = {
	interval = 4000,
	chance = 10
}

monster.strategiesTarget = {
	nearest = 70,
	health = 10,
	damage = 10,
	random = 10,
}

monster.flags = {
	summonable = false,
	attackable = true,
	hostile = true,
	convinceable = false,
	pushable = false,
	rewardBoss = false,
	illusionable = true,
	canPushItems = true,
	canPushCreatures = true,
	staticAttackChance = 70,
	targetDistance = 2,
	runHealth = 50,
	healthHidden = false,
	isBlockable = false,
	canWalkOnEnergy = true,
	canWalkOnFire = false,
	canWalkOnPoison = false,
	pet = false
}

monster.light = {
	level = 0,
	color = 0
}

monster.voices = {
	interval = 5000,
	chance = 10,
	{text = "Gimme! Gimme!", yell = false}
}

monster.loot = {

	{name = "platinum coin", chance = 47500, maxCount = 6},
	{name = "Naga Armring", chance = 8500},
	{name = "Naga Earring", chance = 9500},
	{name = "Naga Archer Scales", chance = 6500},
	{name = "silver brooch", chance = 17500},
	{name = "Crossbow", chance = 16500},
	{name = "bow", chance = 15500},
	{name = "emerald bangle", chance = 14500},
	{name = "ornate crossbow", chance = 12500}

}

monster.attacks = {
	{name ="melee", interval = 2000, chance = 100, minDamage = 0, maxDamage = -340},
	{name ="combat", interval = 1500, chance = 30, type = COMBAT_PHYSICALDAMAGE, minDamage = -250, maxDamage = -550, shootEffect = CONST_ANI_CRYSTALLINEARROW, range = 5, radius = 3, effect = CONST_ME_STONES, target = true},
	{name ="combat", interval = 2000, chance = 10, type = COMBAT_DEATHDAMAGE, minDamage = -200, maxDamage = -370, length = 8, spread = 3, effect = CONST_ME_MORTAREA, target = false}
}

monster.defenses = {
	defense = 35,
	armor = 63,
	{name ="combat", interval = 2000, chance = 10, type = COMBAT_HEALING, minDamage = 600, maxDamage = 900, effect = CONST_ME_MAGIC_BLUE, target = false}
}

monster.elements = {
	{type = COMBAT_PHYSICALDAMAGE, percent = 110},
	{type = COMBAT_ENERGYDAMAGE, percent = 20},
	{type = COMBAT_EARTHDAMAGE, percent = 115},
	{type = COMBAT_FIREDAMAGE, percent = 80},
	{type = COMBAT_LIFEDRAIN, percent = 100},
	{type = COMBAT_MANADRAIN, percent = 0},
	{type = COMBAT_DROWNDAMAGE, percent = 100},
	{type = COMBAT_ICEDAMAGE, percent = 20},
	{type = COMBAT_HOLYDAMAGE , percent = 0},
	{type = COMBAT_DEATHDAMAGE , percent = 0}
}

monster.immunities = {
	{type = "paralyze", condition = true},
	{type = "outfit", condition = false},
	{type = "invisible", condition = true},
	{type = "bleed", condition = false}
}

mType:register(monster)
