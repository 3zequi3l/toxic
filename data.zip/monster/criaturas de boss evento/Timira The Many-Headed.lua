local mType = Game.createMonsterType("Timira The Many-Headed")
local monster = {}

monster.description = "a Timira The Many-Headed"
monster.experience = 100000
monster.outfit = {
	lookType = 1542,
	lookHead = 94,
	lookBody = 94,
	lookLegs = 94,
	lookFeet = 88,
	lookAddons = 3,
	lookMount = 0
}

monster.health = 500000
monster.maxHealth = 500000
monster.race = "blood"
monster.corpse = 0
monster.speed = 200
monster.manaCost = 0
monster.maxSummons = 0

monster.changeTarget = {
	interval = 4000,
	chance = 10
}

monster.strategiesTarget = {
	nearest = 70,
	health = 10,
	damage = 10,
	random = 10,
}

monster.flags = {
	summonable = false,
	attackable = true,
	hostile = true,
	convinceable = false,
	pushable = false,
	rewardBoss = false,
	illusionable = true,
	canPushItems = true,
	canPushCreatures = true,
	staticAttackChance = 70,
	targetDistance = 1,
	runHealth = 50,
	healthHidden = false,
	isBlockable = false,
	canWalkOnEnergy = false,
	canWalkOnFire = false,
	canWalkOnPoison = false,
	pet = false
}

monster.light = {
	level = 0,
	color = 0
}

monster.voices = {
	interval = 5000,
	chance = 10,
	{text = "Gimme! Gimme!", yell = false}
}

monster.loot = {
	{name = "crystal coin", chance = 100000, maxCount = 100},
	{name = "Berserk Potion", chance = 1000, maxCount = 15},
	{name = "Bullseye Potion", chance = 1000, maxCount = 15},
	{name = "Mastermind Potion", chance = 1000, maxCount = 15},
	{name = "Moonstone", chance = 1000},
	{name = "Ultimate Mana Potion", chance = 1000, maxCount = 50},
	{name = "Ultimate Spirit Potion", chance = 100, maxCount = 55},
	{name = "Violet Gem", chance = 1000},
	{name = "White Gem", chance = 1000},
	{name = "Supreme Health Potion", chance = 1000, maxCount = 55},
	{name = "Ultimate Health Potion", chance = 1000, maxCount = 55},
	{name = "Frostflower Boots", chance = 90},
	{name = "Enchanted Turtle Amulet", chance = 90},
	{name = "Dawnfire Sherwani", chance = 90},
	{name = "Naga Crossbow", chance = 90},
	{name = "Feverbloom Boots", chance = 90}
}

monster.attacks = {
	{name ="melee", interval = 1000, chance = 100, minDamage = 1500, maxDamage = -2900},
	{name ="combat", interval = 1050, chance = 100, type = COMBAT_EARTHDAMAGE, minDamage = -1500, maxDamage = -2900, length = 5, spread = 3, effect = CONST_ME_GREEN_RINGS, target = false},
	{name ="combat", interval = 1050, chance = 100, type = COMBAT_ENERGYDAMAGE, minDamage = -1500, maxDamage = -2900, length = 5, spread = 3, effect = CONST_ME_GREEN_RINGS, target = false},
	{name ="combat", interval = 1100, chance = 100, type = COMBAT_PHYSICALDAMAGE, minDamage = -1400, maxDamage = -2900, radius = 4, effect = CONST_ME_HITAREA, target = true}
}

monster.defenses = {
	defense = 35,
	armor = 35,
	{name ="combat", interval = 1500, chance = 25, type = COMBAT_HEALING, minDamage = 1000, maxDamage = 3000, effect = CONST_ME_MAGIC_BLUE, target = false}
}

monster.elements = {
	{type = COMBAT_PHYSICALDAMAGE, percent = 50},
	{type = COMBAT_ENERGYDAMAGE, percent = 80},
	{type = COMBAT_EARTHDAMAGE, percent = 80},
	{type = COMBAT_FIREDAMAGE, percent = 50},
	{type = COMBAT_LIFEDRAIN, percent = 80},
	{type = COMBAT_MANADRAIN, percent = 80},
	{type = COMBAT_DROWNDAMAGE, percent = 80},
	{type = COMBAT_ICEDAMAGE, percent = 80},
	{type = COMBAT_HOLYDAMAGE , percent = 80},
	{type = COMBAT_DEATHDAMAGE , percent = 50}
}

monster.immunities = {
	{type = "paralyze", condition = true},
	{type = "outfit", condition = false},
	{type = "invisible", condition = true},
	{type = "bleed", condition = false}
}

mType:register(monster)
