local mType = Game.createMonsterType("Naga Warrior")
local monster = {}

monster.description = "a Naga Warrior"
monster.experience = 10330
monster.outfit = {
	lookType = 1539,
	lookHead = 104,
	lookBody = 31,
	lookLegs = 85,
	lookFeet = 47,
	lookAddons = 3,
	lookMount = 0
}

monster.health = 9990
monster.maxHealth = 9990
monster.race = "blood"
monster.corpse = 44064
monster.speed = 180
monster.manaCost = 0
monster.maxSummons = 0

monster.changeTarget = {
	interval = 4000,
	chance = 10
}

monster.strategiesTarget = {
	nearest = 70,
	health = 10,
	damage = 10,
	random = 10,
}

monster.flags = {
	summonable = false,
	attackable = true,
	hostile = true,
	convinceable = false,
	pushable = false,
	rewardBoss = false,
	illusionable = true,
	canPushItems = true,
	canPushCreatures = true,
	staticAttackChance = 70,
	targetDistance = 1,
	runHealth = 0,
	healthHidden = false,
	isBlockable = false,
	canWalkOnEnergy = true,
	canWalkOnFire = false,
	canWalkOnPoison = false,
	pet = false
}

monster.light = {
	level = 0,
	color = 0
}

monster.voices = {
	interval = 5000,
	chance = 10,
	{text = "Gimme! Gimme!", yell = false}
}

monster.loot = {

	{name = "platinum coin", chance = 47500, maxCount = 6},
	{name = "Naga Armring", chance = 8500},
	{name = "dagger", chance = 9500},
	{name = "naga warrior scales", chance = 6500},
	{name = "serpent sword", chance = 17500},
	{name = "katana", chance = 16500},
	{name = "plate armor", chance = 14500},
	{name = "knight armor", chance = 13500},
	{name = "violet crystal shard", chance = 12500}

}

monster.attacks = {
	{name ="melee", interval = 1500, chance = 100, minDamage = 100, maxDamage = -200},
	{name ="combat", interval = 1800, chance = 20, type = COMBAT_DEATHDAMAGE, minDamage = -450, maxDamage = -600, length = 5, spread = 8, effect = CONST_ME_MORTAREA, target = false},
	{name ="combat", interval = 1500, chance = 300, type = COMBAT_PHYSICALDAMAGE, minDamage = -560, maxDamage = -700, radius = 4, effect = CONST_ME_DRAWBLOOD, target = false}
}

monster.defenses = {
	defense = 45,
	armor = 78,
	{name ="combat", interval = 2000, chance = 10, type = COMBAT_HEALING, minDamage = 630, maxDamage = 960, effect = CONST_ME_MAGIC_BLUE, target = false}
}

monster.elements = {
	{type = COMBAT_PHYSICALDAMAGE, percent = 0},
	{type = COMBAT_ENERGYDAMAGE, percent = 20},
	{type = COMBAT_EARTHDAMAGE, percent = 0},
	{type = COMBAT_FIREDAMAGE, percent = 0},
	{type = COMBAT_LIFEDRAIN, percent = 0},
	{type = COMBAT_MANADRAIN, percent = 0},
	{type = COMBAT_DROWNDAMAGE, percent = 0},
	{type = COMBAT_ICEDAMAGE, percent = 20},
	{type = COMBAT_HOLYDAMAGE , percent = 0},
	{type = COMBAT_DEATHDAMAGE , percent = 0}
}

monster.immunities = {
	{type = "paralyze", condition = true},
	{type = "outfit", condition = false},
	{type = "invisible", condition = true},
	{type = "bleed", condition = false}
}

mType:register(monster)
