function convertTimeToText(segundos)
    local tempo_em_segundos = segundos
    local days, hours, minutes, seconds = 0, 0, 0, 0

    while tempo_em_segundos ~= 0 do
        if tempo_em_segundos >= 86400 then
            tempo_em_segundos = tempo_em_segundos - 86400
            days = days + 1
        elseif tempo_em_segundos >= 3600 then
            tempo_em_segundos = tempo_em_segundos - 3600
            hours = hours + 1
        elseif tempo_em_segundos >= 60 then
            tempo_em_segundos = tempo_em_segundos - 60
            minutes = minutes + 1
        else
            seconds = tempo_em_segundos
            tempo_em_segundos = 0
        end
    end

    local text = ""
    if days > 0 then
        text = text .. days .. (days == 1 and " day " or " days ") .. hours .. " hours " .. minutes .. " minutes and " .. seconds .. " seconds"
    elseif hours > 0 then
        text = text .. hours .. " hours " .. minutes .. " minutes and " .. seconds .. " seconds"
    elseif minutes > 0 then
        text = text .. minutes .. " minutes and " .. seconds .. " seconds"
    else
        text = text .. seconds .. " seconds"
    end
    return text
end