function Container.isContainer(self)
	return true
end

function Container.createLootItem(self, item, boolCharm)
	if self:getEmptySlots() == 0 then
		return 0
	end

	local itemCount = 0
	local randvalue = getLootRandom()
	local lootBlockType = ItemType(item.itemId)
	local chanceTo = item.chance

	if not lootBlockType then
		return
	end

	if boolCharm and lootBlockType:getType() == ITEM_TYPE_CREATUREPRODUCT then
		chanceTo = (chanceTo * (GLOBAL_CHARM_GUT + 100))/100
	end
	
	local player = Player(self:getCorpseOwner())
	if player then -- vip player loot bonus
		if player:isVip() then
			chanceTo = chanceTo + (chanceTo * VIP_SYSTEM_CONFIG.loot_bonus)
		end
	end
	
	if randvalue < chanceTo then
		if lootBlockType:isStackable() then
			local maxc, minc = item.maxCount or 1, item.minCount or 1
			itemCount = math.max(0, randvalue % (maxc - minc + 1)) + minc			
		else
			itemCount = 1
		end
	end
	
	local tmpItem = false
	while (itemCount > 0) do
		local n = math.min(itemCount, 100)
		itemCount = itemCount - n
		
		 tmpItem = self:addItem(item.itemId, n)
		if not tmpItem then
			return -1
		end

		if tmpItem:isContainer() then
			for i = 1, #item.childLoot do
				if not tmpItem:createLootItem(item.childLoot[i]) then
					tmpItem:remove()
					return -1
				end
			end
		end

		if item.subType ~= -1 then
			tmpItem:transform(item.itemId, item.subType)
		elseif lootBlockType:isFluidContainer() then
			tmpItem:transform(item.itemId, 0)
		end

		if item.actionId ~= -1 then
			tmpItem:setActionId(item.actionId)
		end

		if item.text and item.text ~= "" then
			tmpItem:setText(item.text)
		end
	end
	return tmpItem and tmpItem.uid or 0
end

-- function Container.getItemsById(self, itemId)
    -- local list = {}
    -- for index = 0, (self:getSize() - 1) do
        -- local item = self:getItem(index)
        -- if item then
            -- if item:isContainer() then
                -- local rlist = item:getItemsById(itemId)
                -- if type(rlist) == 'table' then
                    -- for _, v in pairs(rlist) do
                        -- table.insert(list, v)
                    -- end
                -- end
            -- else
                -- if item:getId() == itemId then
                    -- table.insert(list, item)
                -- end
            -- end
        -- end
    -- end
    -- return list
-- end