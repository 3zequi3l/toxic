RESET_config = {
	resetHelpMsg = "O n�mero de resets que voc� tem, � convertido em b�nus para Skill/Loot/StaminaRegen, E upar vai ficando cada vez mais d�ficil!",
	resetStorage = 65555,
    backToLevel = 8,
    redskull = true, -- need to be without redskull to reset?
    battle = false, -- need to be without battle to reset?
    pz = false, -- need to be in protect zone to reset?
    stages = {
        {resets = 4, level = 350, premium = 330},
        {resets = 9, level = 350, premium = 340},
        {resets = 14, level = 350, premium = 355},
        {resets = 19, level = 350, premium = 360},
        {resets = 24, level = 350, premium = 370},
        {resets = 29, level = 350, premium = 380},
        {resets = 34, level = 410, premium = 400},
        {resets = 39, level = 430, premium = 420},
        {resets = 44, level = 450, premium = 440},
        {resets = 49, level = 480, premium = 470},
        {resets = 54, level = 510, premium = 500},
        {resets = 59, level = 550, premium = 540},
        {resets = 64, level = 590, premium = 580},
        {resets = 69, level = 630, premium = 620},
        {resets = 74, level = 680, premium = 670},
        {resets = 79, level = 730, premium = 720},
        {resets = 84, level = 780, premium = 770},
        {resets = 89, level = 860, premium = 840},
        {resets = 94, level = 930, premium = 910},
        {resets = 2^1024, level = 1010, premium = 990}
    }
}

function math.percent(percent,maxvalue)
    if tonumber(percent) and tonumber(maxvalue) then
        return (maxvalue*percent)/100
    end
    return false
end

function Player.someValueWithResetBonus(self, value)
	if not self then
		return false
	end
	if not value then
		return false
	end
	local totalResets = self:getStorageValue(RESET_config.resetStorage) or 0
	if totalResets > 1 then
		local formula = totalResets * 0.2
		local bonusForSome = math.percent(formula,value)
		return value + bonusForSome
	end
	return false
end

function Player.doPlayerReset(self, words, param)
    local function getExperienceForLevel(lv)
        lv = lv -1
        return ((50 * lv * lv * lv) - (150 * lv * lv) + (400 * lv)) / 3
    end
    local function getselfResets()
        local resets = self:getStorageValue(RESET_config.resetStorage)
        return resets < 0 and 0 or resets
    end
  
    local function doselfAddResets(count)
        self:setStorageValue(RESET_config.resetStorage, getselfResets() + count)
    end
  
    if RESET_config.redskull and self:getSkull() == 4 then
        self:sendCancelMessage("You need to be without red skull to reset.")
        return false
    elseif RESET_config.pz and not getTilePzInfo(self:getPosition()) then
        self:sendCancelMessage("You need to be in protection zone to reset.")
        return false
    elseif RESET_config.battle and self:getCondition(CONDITION_INFIGHT) then
        self:sendCancelMessage("You need to be without battle to reset.")
        return false
    end
    
    local days = self:customGetPremiumDays()
    local resetLevel = 0
    for x, y in ipairs(RESET_config.stages) do
        if getselfResets() <= y.resets then
            if days == 0 then
                resetLevel =  y.level
                break
            else               
                resetLevel = self:isPremium() and y.premium
                break
            end
        end
    end
  
    if self:getLevel() < resetLevel then
        self:sendCancelMessage("You need level " .. resetLevel .. " or more to reset.")
        return false
    end
  
	for xId = SKILL_FIST, SKILL_FISHING do
		self:setSkillLevel(xId, 10, 0)
	end
	local expStagex = getRateFromTable(experienceStages, self:getLevel(), configManager.getNumber(configKeys.RATE_EXP))
	local skillStagex = getRateFromTable(skillsStages, self:getSkillLevel(skill), skillRate)
	
    doselfAddResets(1)
    -- local healthMax, manaMax, health, mana = self:getMaxHealth(), self:getMaxMana(), self:getHealth(), self:getMana()
    self:removeExperience(self:getExperience() - getExperienceForLevel(RESET_config.backToLevel))
	self:setMaxHealth(155)
	self:setMaxMana(60)
	self:addHealth(155)
	self:addMana(60)
	self:setMagicLevel(2, 5936)
	self:getPosition():sendMagicEffect(CONST_ME_FIREWORK_RED)
	self:sendTextMessage(MESSAGE_INFO_DESCR, "Now you have " .. getselfResets() .. " " .. (getselfResets() == 1 and "reset" or "resets") .. ". \nReset Stats: \n   Experience - " .. math.percent(getselfResets()*0.2,expStagex) .. "%\z
																				\n   Skill/Loot/StaminaRegen + " .. math.percent(getselfResets()*0.2,skillStagex) .. "%\n" .. RESET_config.resetHelpMsg)
	
    return true
end

