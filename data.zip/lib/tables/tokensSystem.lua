-- tokens:
-- GOLD TOKEN = 25377
-- SILVER TOKEN = 25172
-- COOPER = 25378
-- IRON = 25376
-- PLATINUM = 25379
-- TITANIUM = 25380

CUSTOM_TOKENS_CONFIG = {
	["Gold Token"] = {id = 25377, dataId = "goldtokens"},
	["Silver Token"] = {id = 25172, dataId = "silvertokens"},
	["Cooper Token"] = {id = 25378, dataId = "coopertokens"},
	["Iron Token"] = {id = 25376, dataId = "irontokens"},
	["Platinum Token"] = {id = 25379, dataId = "platinumtokens"},
	["Titanium Token"] = {id = 25380, dataId = "titaniumtokens"},
}

-- for k, settings in pairs(CUSTOM_TOKENS_CONFIG) do
	-- print(k)
-- end

-- clicar no token e converter token para database

-- Player.getTokenBalance(self, type)
-- ele tem que retornar o balance de todos os tokens do player

function Player.getSpecificTokenBalance(self, token)
	resultId = db.storeQuery("SELECT `" .. token .. "` FROM `account_tokens` WHERE `account_id` = " .. self:getAccountId())
	if not resultId then 
		return 0 
	end
	return result.getDataInt(resultId, token)
end

function Player.setSpecificTokenBalance(self, token, value)
	if not token then
		return false
	end
	if not value then
		return false
	end
	local try = db.query("UPDATE `account_tokens` SET `" .. token .. "` = " .. value .. " WHERE `account_id` = " .. self:getAccountId())
	if try then
		return true
	end
	return false
end
-- Player.removeTokenBalance(self, type, value)
function Player.removeTokenBalance(self, type, value)
	local balance = self:getSpecificTokenBalance(type)
	if balance then
		if self:setSpecificTokenBalance(type, balance - value) then
			return true
		end
	end
	return false
end

-- Player.addTokenBalance(self, quantidade, type)
function Player.addTokenBalance(self, type, value)
	local balance = self:getSpecificTokenBalance(type)
	if balance then
		if self:setSpecificTokenBalance(type, balance + value) then
			return true
		end
	end
	return false
end
-- type = goldtokens, silvertokens, ...
