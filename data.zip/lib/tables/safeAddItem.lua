function Player.safeAddItem(self, itemId, count)
	local container = self:chooseIdealContainer()
	if container then
		container:addItem(itemId, count)
		return true
	end
	return false
end

function Player.chooseIdealContainer(self)
	local container = self:getSlotItem(CONST_SLOT_BACKPACK)
	if container then
		if container:getEmptySlots() > 0 then
			return container
		end
	else
		local container = self:getSlotItem(CONST_SLOT_STORE_INBOX)
		if container then
			if container:getEmptySlots() > 0 then
				return container
			end
		end
	end
	return false
end