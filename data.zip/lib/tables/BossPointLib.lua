BOSS_REWARD_POINTS_EXCHANGE_ITEMS = {
	[32594] = { ---- assassin doll 
		count = 1,
		points = 60,
	},
	[23806] = { -- black kinight
		count = 1,
		points = 70,
	},
	[32401] = { --- cintzen doll
		count = 1,
		points = 35,
	},
	[24810] = { --- dark wirzad
		count = 1,
		points = 55,
	},
		[21469] = {  --- friend ship amulet
		count = 1,
		points = 75,
	},
		[21472] = { --- phoenix
		count = 1,
		points = 45,
	},
		[24682] = { --- frozen heart
		count = 1,
		points = 50,
	},
		[33552] = {  --- mathmaster shield
		count = 1,
		points = 50,
	},
		[11393] = { -- lucky clover amulet
		count = 1,
		points = 100,
	},
		[11401] = { -- tibiorasx box
		count = 1,
		points = 100,
	},
			[22473] = { -- small stamina
		count = 1,
		points = 20,
	},
			[22472] = { -- full stamina
		count = 1,
		points = 30,
	},
}

function Player.exchangePointsForItem(self, itemId)
	if not self or not itemId then return false end
	if BOSS_REWARD_POINTS_EXCHANGE_ITEMS[itemId] then
		local points = self:getBossPoints()
		if points then
			local temp = BOSS_REWARD_POINTS_EXCHANGE_ITEMS[itemId]
			if points >= temp.points then
				if not self:safeAddItem(itemId, temp.count) then
					return false
				end
				self:setBossPoints(points - temp.points)
				return true
			end
		end
	end
	return false
end

function Player.getBossPoints(self)
	if not self then return false end
	if self:getStorageValue(Storage.BOSS_REWARD_POINTS) == -1 then
		self:setStorageValue(Storage.BOSS_REWARD_POINTS, 0)
	end
	return self:getStorageValue(Storage.BOSS_REWARD_POINTS)
end

function Player.setBossPoints(self, value)
	if not self or not value then return false end
	local points = self:getBossPoints()
	if points then
		self:setStorageValue(Storage.BOSS_REWARD_POINTS, value)
		return true
	end
	return false
end

function Player.addBossPoints(self, value)
	if not self or not value then return false end
	local points = self:getBossPoints()
	if points then
		if self:setBossPoints(points + value) then
			self:sendTextMessage(MESSAGE_LOOK, "you gained " .. value .. " boss point")
			return true
		end
	end
	return false
end