REWARD_MOUNTS_OUTFITS = {
    ["The Pale Worm"] = {
        OUTFIT = {
            gender = {[0] = 1271, [1] = 1270},
        },
        -- MOUNT = ,
    },
---------------------------------------------------------------		
	    ["Tentuglys Head"] = {
        OUTFIT = {
            gender = {[0] = 1372, [1] = 1371},
        },
        -- MOUNT = ,
    },
---------------------------------------------------------------		
	    ["Ferumbras Mortal Shell"] = {
        OUTFIT = {
            gender = {[0] = 845, [1] = 846},
        },
        -- MOUNT = ,
    },
---------------------------------------------------------------		
	    ["King Zelos"] = {
        OUTFIT = {
            gender = {[0] = 1244, [1] = 1243},
        },
        -- MOUNT = ,
    },
---------------------------------------------------------------	
	     ["Grand Master Oberon"] = {
         OUTFIT = {
            -- gender = {[0] = 1490, [1] = 1489},
         },
         MOUNT = 368,
     },
-------------------------------------------------------------	
	    -- ["Grand Master Oberon"] = {
        -- OUTFIT = {
            -- gender = {[0] = 1490, [1] = 1489},
        -- },
        -- MOUNT = 368,
    -- },
}

function REWARD_MOUNTS_OUTFITS:onDeath(monster, killer)
    if not monster or not killer then
        return false
    end
    if not killer:isPlayer() or not monster:isMonster() then
        return false
    end
    if not self[monster:getName()] then
        return false
    end
    local data = self[monster:getName()]
    if data.OUTFIT then
        local looktype = data.OUTFIT.gender[killer:getSex()]
        if not killer:hasOutfit(looktype) then
            killer:addOutfit(looktype)
            killer:sendTextMessage(MESSAGE_EVENT_ADVANCE, "You received a OUTFIT!")
        end
    end
    if data.MOUNT then
        if not killer:hasMount(data.MOUNT) then
            killer:addMount(data.MOUNT)
            killer:sendTextMessage(MESSAGE_EVENT_ADVANCE, "You received a MOUNT!")
            return true
        end
    end
    return false
end