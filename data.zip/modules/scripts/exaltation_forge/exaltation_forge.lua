Exaltation_Forge = {}

Exaltation_Forge.Resource_Type = {
	Bank = 0x00,
	Inventory = 0x01,
	Dust = 0x46,
	Slivers = 0x47,
	Exalted_Cores = 0x48,
}

Exaltation_Forge.Config = {
	Dust_Drop_Chance = 100000,
	Dust_Drop_Min = 1,
	Dust_Drop_Max = 3,
	Sliver_Drop_Min = 3,
	Sliver_Drop_Max = 7,
	Sliver_Id = 41944,
	Exalted_Core_Id = 41945,
	Exaltation_Chest_Id = 42396,
	Fusion_Dust_Cost = 100,
	Base_Success_Rate = 50,
	Extra_Success_Rate = 15,
	Premium_Success_Rate = 20,
	Tier_Loss_Rate = 100,
	Tier_Loss_Minus_Rate = 50,
	Transfer_Dust_Cost = 100,
	Transfer_Core_Cost = 1,
	Convert_Dust_Cost = 20,
	Convert_Dust_Slivers = 3,
	Convert_Slivers_Cost = 50,
	Convert_Slivers_Cores = 1,
	Max_Dust = 225,
	Increase_Dust_Minus_Cost = 75,
	Increase_Dust_Jump = 1,
	Lucky_Bonus_Chance = 10000,
}

Exaltation_Forge.Forging_Type = {
	Fusion = 0,
	Transfer = 1,
}

Exaltation_Forge.Lucky_Bonus_Type = {
	None = 0,
	NotUsedDust = 1, -- for both
	NotUsedExaltedCores = 2, -- for both
	NotUsedGold = 3, -- for both
	OnlyLostOneTier = 4, -- for succeed
	SecondItemNotConsumed = 5, -- for succeed
	BothItemsAdditionalTier = 6, -- for succeed
	TwoTiersInsteadOfOne = 7, -- for succeed
	SecondItemNotLosedATier = 8, -- for failed
}

Exaltation_Forge.InfluencedChances = {
	{level = 5, chances = 125},
	{level = 4, chances = 250},
	{level = 3, chances = 500},
	{level = 2, chances = 1000},
	{level = 1, chances = 2000},
}


Exaltation_Forge.Client_Packets = {
	ExecuteAction = 0xBF,
	RequestData = 0xC0,
}

Exaltation_Forge.Action_Type = {
	Fusion = 0,
	Transfer = 1,
	Convert_Dust = 2,
	Convert_Slivers = 3,
	Increase_Dust_Limit = 4,
}

Exaltation_Forge.Server_Packets = {
	InitialData = 0x86,
	OpenForge = 0x87,
	History = 0x88,
	CloseForge = 0x89,
	ForgingResult = 0x8A,
	Resources = 0xEE,
}

function onRecvbyte(player, msg, byte)
	if byte == Exaltation_Forge.Client_Packets.RequestData then
		player:sendRequestData(msg)
	elseif byte == Exaltation_Forge.Client_Packets.ExecuteAction then
		parseExecuteAction(player, msg)
	end
end

function searchForItemInContainer(resultTable, container, itemIdToSearch, tier)
	local size = container:getSize()
	if size > 0 then
		for i= 0, size-1 do
			local item = container:getItem(i)
			local itemTier = item:getAttribute(ITEM_ATTRIBUTE_TIER) and item:getAttribute(ITEM_ATTRIBUTE_TIER) or 0
			if item then
				local itemType = ItemType(item:getId())
				if itemIdToSearch == item:getId() and tier == itemTier then
					table.insert(resultTable, item)
				end
				if itemType:isContainer() then
					searchForItemInContainer(resultTable, item, itemIdToSearch, tier)
				end	
			end
		end
	end
end

function Player.sendForgingData(player)
	local msg = NetworkMessage()
	msg:addByte(Exaltation_Forge.Server_Packets.InitialData)
	local classificationSize = table.size(classification)
	msg:addByte(classificationSize)
	for i=1, classificationSize do
		msg:addByte(i)
		msg:addByte(#classification[i].Upgrades)
		for _, data in pairs(classification[i].Upgrades) do
			msg:addByte(data.TierId)
			msg:addU64(data.Price)
		end
	end
	
	msg:addByte(Exaltation_Forge.Config.Convert_Dust_Cost)
	msg:addByte(Exaltation_Forge.Config.Convert_Dust_Slivers)
	msg:addByte(Exaltation_Forge.Config.Convert_Slivers_Cost)
	msg:addByte(Exaltation_Forge.Config.Increase_Dust_Minus_Cost)
	msg:addByte(player:getMaximumDust())
	msg:addByte(Exaltation_Forge.Config.Max_Dust)
	msg:addByte(Exaltation_Forge.Config.Fusion_Dust_Cost)
	msg:addByte(Exaltation_Forge.Config.Transfer_Dust_Cost)
	msg:addByte(Exaltation_Forge.Config.Base_Success_Rate)
	msg:addByte(Exaltation_Forge.Config.Extra_Success_Rate)
	msg:addByte(Exaltation_Forge.Config.Tier_Loss_Minus_Rate)

	msg:sendToPlayer(player)
end
	

function Player.searchForItem(player, itemIdToSearch, tier)
	local result = {}
	for slot = CONST_SLOT_FIRST, CONST_SLOT_LAST do
		local slotItem = player:getSlotItem(slot)
		if slotItem then
			local itemTier = slotItem:getAttribute(ITEM_ATTRIBUTE_TIER) and slotItem:getAttribute(ITEM_ATTRIBUTE_TIER) or 0
			local itemId = slotItem:getId()
			if itemId == itemIdToSearch and tier == itemTier then
				table.insert(result, slotItem)
			end
			if ItemType(itemId):isContainer() then
				searchForItemInContainer(result, slotItem, itemIdToSearch, tier)
			end
		end
	end
	return result
end

function getClassificationMaxTier(class)
	return #classification[class].Upgrades
end

function getFusionCost(class, tier)
	return classification[class].Upgrades[tier].Price
end

function parseFusionAction(player, msg)
	if player:getFreeCapacity() < ItemType(Exaltation_Forge.Config.Exaltation_Chest_Id):getWeight() then
		player:sendErrorDialog("You don't have enough capacity for the exaltation chest.")
		return
	end
	if player:getDust() < Exaltation_Forge.Config.Fusion_Dust_Cost then
		player:sendErrorDialog("You don't have enough dust.")
		return
	end
	local firstItem = msg:getU16()
	local tier = msg:getByte()
	if tier >= 10 then
		player:sendErrorDialog("The maximum tier for an item is 10.")
		return
	end
	local it = Game.getItemIdByClientId(firstItem)
	if not it then
		player:sendErrorDialog("Item does not exist.")
		return
	end
	local class = it:getClassification()
	if class == 0 then
		player:sendErrorDialog("This item can't be fusioned.")
		return
	end
	local maxTier = getClassificationMaxTier(class)
	if maxTier < tier then
		player:sendErrorDialog("This item can't get to that tier.")
		return
	end
	local secondItem = msg:getU16()
	local exaltationCores = 0
	local successRate = Exaltation_Forge.Config.Base_Success_Rate
	local tierLossRate = Exaltation_Forge.Config.Tier_Loss_Rate
	local extraSuccess = msg:getByte() == 1
	if extraSuccess then
		successRate = successRate + Exaltation_Forge.Config.Extra_Success_Rate
		exaltationCores = exaltationCores + 1
	end
	local lessLossRate = msg:getByte() == 1
	if lessLossRate then
		tierLossRate = tierLossRate - Exaltation_Forge.Config.Tier_Loss_Minus_Rate
		exaltationCores = exaltationCores + 1
	end
	if exaltationCores > 0 then
		if player:getItemCount(Exaltation_Forge.Config.Exalted_Core_Id) < exaltationCores then
			player:sendErrorDialog("You don't have enough exalted cores.")
			return
		end
	end
	
	local tierItems = player:searchForItem(it:getId(), tier)
	if not tierItems or #tierItems < 2 then
		player:sendErrorDialog("You don't have the required items.")
		return
	end
	local chances = math.random(1, 100)
	
	local bonusChance = math.random(1, 100000)
	local bonusData = {Exaltation_Forge.Lucky_Bonus_Type.None}
	if bonusChance <= Exaltation_Forge.Config.Lucky_Bonus_Chance then
		local possiblesOutcomes = {
			Exaltation_Forge.Lucky_Bonus_Type.NotUsedDust,
			Exaltation_Forge.Lucky_Bonus_Type.NotUsedGold
		}
		if exaltationCores > 0 then
			table.insert(possiblesOutcomes, Exaltation_Forge.Lucky_Bonus_Type.NotUsedExaltedCores)
		end
		if chances <= successRate then
			if tier > 1 then
				table.insert(possiblesOutcomes, Exaltation_Forge.Lucky_Bonus_Type.OnlyLostOneTier)
			end
			table.insert(possiblesOutcomes, Exaltation_Forge.Lucky_Bonus_Type.SecondItemNotConsumed)
			table.insert(possiblesOutcomes, Exaltation_Forge.Lucky_Bonus_Type.BothItemsAdditionalTier)
			if maxTier >= tier + 1 then
				table.insert(possiblesOutcomes, Exaltation_Forge.Lucky_Bonus_Type.TwoTiersInsteadOfOne)
			end
		end
		bonusData[1] = possiblesOutcomes[math.random(1, #possiblesOutcomes)]
		if bonusData[1] == Exaltation_Forge.Lucky_Bonus_Type.NotUsedExaltedCores then
			bonusData[2] = exaltationCores
		elseif bonusData[1] > Exaltation_Forge.Lucky_Bonus_Type.NotUsedGold then
			bonusData[2] = firstItem
			if bonusData[1] == Exaltation_Forge.Lucky_Bonus_Type.OnlyLostOneTier then
				bonusData[3] = tier - 1
			elseif bonusData[1] == Exaltation_Forge.Lucky_Bonus_Type.SecondItemNotConsumed then
				bonusData[3] = tier
			elseif bonusData[1] == Exaltation_Forge.Lucky_Bonus_Type.BothItemsAdditionalTier then
				bonusData[3] = tier + 1
			elseif bonusData[1] == Exaltation_Forge.Lucky_Bonus_Type.TwoTiersInsteadOfOne then
				bonusData[3] = tier + 2
			end
		end
	end
	
	if player:getFreeCapacity() < ItemType(Exaltation_Forge.Config.Exaltation_Chest_Id):getWeight() then
		player:sendErrorDialog("You don't have enough capacity for the exaltation chest.")
		return
	end
	
	local moneyCost = getFusionCost(class, tier + 1)
	if (player:getMoney() + player:getBankBalance()) < moneyCost then
		player:sendErrorDialog("You don't have enough money.")
		return
	end
	
	local chest = Game.createItem(Exaltation_Forge.Config.Exaltation_Chest_Id, 1)
	if not chest:moveTo(player) then
		player:sendErrorDialog("Make some space for the exaltation chest.")
		return
	end
	
	if bonusData[1] ~= Exaltation_Forge.Lucky_Bonus_Type.NotUsedGold then
		player:removeMoneyNpc(moneyCost)
	end
	if exaltationCores > 0 and bonusData[1] ~= Exaltation_Forge.Lucky_Bonus_Type.NotUsedExaltedCores then
		player:removeItem(Exaltation_Forge.Config.Exalted_Core_Id, exaltationCores)
	end
	if bonusData[1] ~= Exaltation_Forge.Lucky_Bonus_Type.NotUsedDust then
		player:setDust(player:getDust() - Exaltation_Forge.Config.Fusion_Dust_Cost)
	end
	tierItems[1]:moveTo(chest)
	tierItems[2]:moveTo(chest)
	local newTier
	if chances <= successRate then
		newTier = tier + 1
		if bonusData[1] == Exaltation_Forge.Lucky_Bonus_Type.TwoTiersInsteadOfOne then
			newTier = newTier + 1
		end		
		tierItems[1]:setAttribute(ITEM_ATTRIBUTE_TIER, newTier)
		if bonusData[1] == Exaltation_Forge.Lucky_Bonus_Type.OnlyLostOneTier then
			tierItems[2]:setAttribute(ITEM_ATTRIBUTE_TIER, tier - 1)
		elseif bonusData[1] == Exaltation_Forge.Lucky_Bonus_Type.BothItemsAdditionalTier then
			tierItems[2]:setAttribute(ITEM_ATTRIBUTE_TIER, tier + 1)
		elseif bonusData[1] ~= Exaltation_Forge.Lucky_Bonus_Type.SecondItemNotConsumed then
			tierItems[2]:remove()
		end
	else
		local tierLossChance = math.random(1, 100)
		if tierLossChance <= tierLossRate then
			if tier == 0 then
				tierItems[2]:remove()
			else
				newTier = tier - 1
				tierItems[2]:setAttribute(ITEM_ATTRIBUTE_TIER, newTier)
			end
		else
			bonusData[1] = Exaltation_Forge.Lucky_Bonus_Type.SecondItemNotLosedATier
			bonusData[2] = firstItem
			bonusData[3] = tier
		end
	end
	player:sendForgingResult(Exaltation_Forge.Forging_Type.Fusion, (chances <= successRate and 1 or 0), firstItem, tier, firstItem, (chances <= successRate and tier + 1 or tier), bonusData)
	player:openExaltationForge()

	local description = (chances > successRate and "Uns" or "S") .. "uccessful\n\n" ..
	"Fusion partners:\n" ..
	"    * First item: " .. it:getArticle() .. " " .. it:getName() .. ", tier " .. tier .. "\n" ..
	"    * Second item: " .. it:getArticle() .. " " .. it:getName() .. ", tier " .. tier .. "\n\n" ..
	"Result:\n" ..
	"    * First item: "
	if bonusData[1] == Exaltation_Forge.Lucky_Bonus_Type.TwoTiersInsteadOfOne then
		description = description .. "tier + 2"
	elseif chances <= successRate then
		description = description .. "tier + 1"
	else
		description = description .. "unchanged"
	end
	description = description .. "\n" ..
	"    * Second item: "
	if bonusData[1] == Exaltation_Forge.Lucky_Bonus_Type.OnlyLostOneTier then
		description = description .. "tier - 1"
	elseif bonusData[1] == Exaltation_Forge.Lucky_Bonus_Type.BothItemsAdditionalTier then
		description = description .. "tier + 1"
	elseif bonusData[1] == Exaltation_Forge.Lucky_Bonus_Type.SecondItemNotConsumed then
		description = description .. "unchanged"
	else
		description = description .. "consumed"
	end
	description = description .. "\n\n"
	if bonusData[1] ~= Exaltation_Forge.Lucky_Bonus_Type.None then
		description = description .. "Bonus effect:\n" ..
		"    * "
		if bonusData[1] == Exaltation_Forge.Lucky_Bonus_Type.NotUsedDust then
			description = description .. "No dust was used"
		elseif bonusData[1] == Exaltation_Forge.Lucky_Bonus_Type.NotUsedExaltedCores then
			description = description .. "No exalted cores were used"
		elseif bonusData[1] == Exaltation_Forge.Lucky_Bonus_Type.NotUsedGold then
			description = description .. "No gold was used"
		elseif bonusData[1] == Exaltation_Forge.Lucky_Bonus_Type.OnlyLostOneTier then
			description = description .. "Second item was not consumed and only lost a tier"
		elseif bonusData[1] == Exaltation_Forge.Lucky_Bonus_Type.SecondItemNotConsumed then
			description = description .. "Second item was not consumed"
		elseif bonusData[1] == Exaltation_Forge.Lucky_Bonus_Type.BothItemsAdditionalTier then
			description = description .. "Second item was not consumed and gained a tier"
		elseif bonusData[1] == Exaltation_Forge.Lucky_Bonus_Type.TwoTiersInsteadOfOne then
			description = description .. "First item gained two tiers instead of one"
		elseif bonusData[1] == Exaltation_Forge.Lucky_Bonus_Type.SecondItemNotLosedATier then
			description = description .. "Second item retained with unchanged tier"
		end
		description = description .. "\n\n"
	end
	description = description .. "Invested:\n"
	if extraSuccess then
		description = description .. "    * Exalted core (to increase rate of success)\n"
	end
	if lessLossRate then
		description = description .. "    * Exalted core (to protect second item)\n"
	end
	if bonusData[1] ~= Exaltation_Forge.Lucky_Bonus_Type.NotUsedDust then
		description = description .. "    * " .. Exaltation_Forge.Config.Fusion_Dust_Cost .. " dust\n"
	end
	if bonusData[1] ~= Exaltation_Forge.Lucky_Bonus_Type.NotUsedGold then
		if moneyCost > 1000000 then
			description = description .. "    * " .. moneyCost/1000000 .. " kk gold\n"
		else
			description = description .. "    * " .. moneyCost/1000 .. " k gold\n"
		end
	end
	db.query("INSERT INTO forge_history (player_id, description, timestamp, result) VALUES ("..player:getGuid()..", '"..description.."', ".. os.time() .. ", " .. (chances <= successRate and 1 or 0) .. ")")
end

function parseTransferAction(player, msg)
	if player:getFreeCapacity() < ItemType(Exaltation_Forge.Config.Exaltation_Chest_Id):getWeight() then
		player:sendErrorDialog("You don't have enough capacity for the exaltation chest.")
		return
	end
	local firstClientId = msg:getU16()
	local firstIt = Game.getItemIdByClientId(firstClientId)
	if not firstIt then
		player:sendErrorDialog("Sorry, that item does not exist.")
		return
	end
	local firstClassification = firstIt:getClassification()
	if firstClassification == 0 then
		player:sendErrorDialog("Sorry, this item can't be transfered.")
		return
	end
	
	local firstTier = msg:getByte()
	local maxTier = getClassificationMaxTier(firstClassification)
	if firstTier > maxTier then
		player:sendErrorDialog("This tier does not exist.")
		return
	end
	local secondClientId = msg:getU16()
	local secondIt = Game.getItemIdByClientId(secondClientId)
	if not secondIt then
		player:sendErrorDialog("Sorry, that item does not exist.")
		return
	end
	local secondClassification = secondIt:getClassification()
	if secondClassification == 0 then
		player:sendErrorDialog("Sorry, this item can't be transfered to.")
		return
	end
	
	if firstClassification ~= secondClassification then
		player:sendErrorDialog("Sorry, those items are of different classification.")
		return
	end
	
	if player:getItemCount(Exaltation_Forge.Config.Exalted_Core_Id) < Exaltation_Forge.Config.Transfer_Core_Cost then
		player:sendErrorDialog("Sorry, you don't have enough cores.")
		return
	end
	
	if player:getDust() < Exaltation_Forge.Config.Transfer_Dust_Cost then
		player:sendErrorDialog("Sorry, you don't have enough dust.")
		return
	end
	
	local firstItem = player:searchForItem(firstIt:getId(), firstTier)
	local secondItem = player:searchForItem(secondIt:getId(), 0)
	
	if not firstItem or #firstItem == 0 then
		player:sendErrorDialog("You don't have the transfering item.")
		return
	end
	
	if not secondItem or #secondItem == 0 then
		player:sendErrorDialog("You don't have the item to transfer to.")
		return
	end
	
	local moneyCost = getFusionCost(firstClassification, firstTier)
	if (player:getMoney() + player:getBankBalance()) < moneyCost then
		player:sendErrorDialog("You don't have enough money.")
		return
	end
	
	local chest = Game.createItem(Exaltation_Forge.Config.Exaltation_Chest_Id, 1)
	if not chest:moveTo(player) then
		player:sendErrorDialog("Make some space in your backpack for the exaltation chest.")
		return
	end
	
	player:removeMoneyNpc(moneyCost)
	player:setDust(player:getDust() - Exaltation_Forge.Config.Transfer_Dust_Cost)
	player:removeItem(Exaltation_Forge.Config.Exalted_Core_Id, Exaltation_Forge.Config.Transfer_Core_Cost)
	firstItem[1]:remove()
	secondItem[1]:moveTo(chest)
	secondItem[1]:setAttribute(ITEM_ATTRIBUTE_TIER, firstTier - 1)
	player:sendForgingResult(Exaltation_Forge.Forging_Type.Transfer, 1, firstClientId, firstTier, secondClientId, firstTier - 1, {0})
	player:openExaltationForge()
	return true
end

function parseExecuteAction(player, msg)
	local type = msg:getByte()
	if type == Exaltation_Forge.Action_Type.Fusion then
		parseFusionAction(player, msg)
	elseif type == Exaltation_Forge.Action_Type.Transfer then
		parseTransferAction(player, msg)
	elseif type == Exaltation_Forge.Action_Type.Convert_Dust then
		local cost = Exaltation_Forge.Config.Convert_Dust_Slivers * Exaltation_Forge.Config.Convert_Dust_Cost
		if player:getDust() >= cost then
			player:setDust(player:getDust() - cost)
			player:addItem(Exaltation_Forge.Config.Sliver_Id, Exaltation_Forge.Config.Convert_Dust_Slivers)
			player:openExaltationForge()
			player:sendErrorDialog("You converted " .. cost .. " dust to " .. Exaltation_Forge.Config.Convert_Dust_Slivers .. " slivers.")
			player:getPosition():sendMagicEffect(CONST_ME_BLUE_ENERGY_SPARK)
		else
			player:sendErrorDialog("You don't have enough dust.")
			player:getPosition():sendMagicEffect(CONST_ME_POFF)
		end
	elseif type == Exaltation_Forge.Action_Type.Convert_Slivers then
		local cost = Exaltation_Forge.Config.Convert_Slivers_Cost * Exaltation_Forge.Config.Convert_Slivers_Cores
		if player:removeItem(Exaltation_Forge.Config.Sliver_Id, cost) then
			player:addItem(Exaltation_Forge.Config.Exalted_Core_Id, Exaltation_Forge.Config.Convert_Slivers_Cores)
			player:openExaltationForge()
			player:sendErrorDialog("You converted " .. cost .. " slivers to " .. Exaltation_Forge.Config.Convert_Slivers_Cores .. " core(s).")
			player:getPosition():sendMagicEffect(CONST_ME_BLUE_ENERGY_SPARK)
		else
			player:sendErrorDialog("You don't have enough slivers.")
			player:getPosition():sendMagicEffect(CONST_ME_POFF)
		end
	elseif type == Exaltation_Forge.Action_Type.Increase_Dust_Limit then
		local maximumDust = player:getMaximumDust()
		if maximumDust < Exaltation_Forge.Config.Max_Dust then
			local dustCost = maximumDust - Exaltation_Forge.Config.Increase_Dust_Minus_Cost
			local actualDust = player:getDust()
			if actualDust >= dustCost then
				player:setMaximumDust(maximumDust + Exaltation_Forge.Config.Increase_Dust_Jump)
				player:setDust(actualDust - dustCost)
				player:openExaltationForge()
				player:sendErrorDialog("You increased your maximum dust from " .. maximumDust .. " to " .. maximumDust + Exaltation_Forge.Config.Increase_Dust_Jump .. " at the cost of " .. dustCost .. " dust.")
				player:getPosition():sendMagicEffect(CONST_ME_BLUE_ENERGY_SPARK)
			else
				player:sendErrorDialog("You don't have enough dust.")
				player:getPosition():sendMagicEffect(CONST_ME_POFF)
		end
		else
			player:sendErrorDialog("You have the maximum dust possible.")
			player:getPosition():sendMagicEffect(CONST_ME_POFF)
		end
	end	
end

function Player.sendRequestData(player, msg)

	player:sendForgingData()
	
	local actualPage = msg:getU16()
	local perPage = msg:getByte()
	
	
	local msg = NetworkMessage()
	msg:addResource(Exaltation_Forge.Resource_Type.Bank, player:getBankBalance())
	msg:addResource(Exaltation_Forge.Resource_Type.Inventory, player:getMoney())
	msg:addResource(Exaltation_Forge.Resource_Type.Dust, player:getDust())
	msg:addResource(Exaltation_Forge.Resource_Type.Slivers, player:getItemCount(Exaltation_Forge.Config.Sliver_Id))
	msg:addResource(Exaltation_Forge.Resource_Type.Exalted_Cores, player:getItemCount(Exaltation_Forge.Config.Exalted_Core_Id))
	msg:addByte(Exaltation_Forge.Server_Packets.History)
	
	local total = db.storeQuery("SELECT COUNT(*) as totalRows FROM forge_history WHERE player_id = " .. player:getGuid())
	local query = db.storeQuery("SELECT * FROM forge_history WHERE player_id = " .. player:getGuid() .. " ORDER BY timestamp DESC LIMIT " .. actualPage * perPage .. ", " .. perPage .. "")
	
	local history = {}
	local totalPages = 0
	if query and total then
		totalPages = math.ceil(result.getNumber(total, "totalRows")/perPage)
		repeat
			history[#history + 1] = {result.getNumber(query, "timestamp"), result.getNumber(query, "result"), result.getString(query, "description")} 
		until not result.next(query)
	end
	result.free(total)
	if actualPage > totalPages then
		actualPage = totalPages
	end
	msg:addU16(actualPage) -- ACTUAL PAGE
	msg:addU16(totalPages) -- TOTAL PAGES
	result.free(query)
	msg:addByte(#history) -- TOTAL HISTORY
	if #history > 0 then
		for i=1, #history do
			local data = history[i]
			msg:addU16(data[1] % 65536)
			msg:addU32(math.floor(data[1] / 65536))
			local text = {}
			for t=1, #data[3] do
				text[#text + 1] = string.byte(data[3], t)
			end
			msg:addByte(math.ceil(#text / 256))
			for t=1, math.ceil(#text / 256)*256 do
				msg:addByte(text[t] or 0x00)
			end
			msg:addByte(data[2])
		end
	end
		
	
	-- u16 for secs (os.time() % 65536)
	-- u32 for remnant (os.time() / 65536)
	-- u8 description, for each one 256 bytes, string in bytes, use string.byte
	-- u8 bool for worked or not
	msg:sendToPlayer(player)
end

function NetworkMessage.addResource(msg, type, value)
	msg:addByte(Exaltation_Forge.Server_Packets.Resources)
	msg:addByte(type)
	msg:addU64(value)
end

function searchContainer(resultTable, container)
	local size = container:getSize()
	if size > 0 then
		for i= 0, size-1 do
			local item = container:getItem(i)
			if item then
				local itemType = ItemType(item:getId())
				if itemType:getClassification() ~= 0 then
					local tier = item:getAttribute(ITEM_ATTRIBUTE_TIER) and item:getAttribute(ITEM_ATTRIBUTE_TIER) or 0
					local itemId = item:getId()
					if not resultTable[itemId] then
						resultTable[itemId] = {}
					end
					if not resultTable[itemId][tier] then
						resultTable[itemId][tier] = 0
					end
					resultTable[itemId][tier] = resultTable[itemId][tier] + 1
				end
				if itemType:isContainer() then
					searchContainer(resultTable, item)
				end	
			end
		end
	end
end

function Player.sendForgingResult(player, type, result, firstClientId, firstTier, secondClientId, secondTier, bonusData)
	local msg = NetworkMessage()
	msg:addByte(Exaltation_Forge.Server_Packets.ForgingResult)
	msg:addByte(type)
	msg:addByte(result)
	msg:addU16(firstClientId)
	msg:addByte(firstTier)
	msg:addU16(secondClientId)
	msg:addByte(secondTier)
	msg:addByte(bonusData[1])
	if bonusData[1] == Exaltation_Forge.Lucky_Bonus_Type.NotUsedExaltedCores then
		msg:addByte(bonusData[2])
	elseif bonusData[1] > Exaltation_Forge.Lucky_Bonus_Type.NotUsedGold then
		msg:addU16(bonusData[2])
		msg:addByte(bonusData[3])
	end
	msg:sendToPlayer(player)							
	return true
end

function Player.getUpgradableItems(player)
	local result = {}
	for slot = CONST_SLOT_FIRST, CONST_SLOT_LAST do
		local slotItem = player:getSlotItem(slot)
		if slotItem then
			local itemType = ItemType(slotItem:getId())
			local classification = itemType:getClassification()
			if classification ~= 0 then
				local tier = slotItem:getAttribute(ITEM_ATTRIBUTE_TIER) and slotItem:getAttribute(ITEM_ATTRIBUTE_TIER) or 0 
				if tier < getClassificationMaxTier(classification) then
					local itemId = slotItem:getId()
					if not result[itemId] then
						result[itemId] = {}
					end
					if not result[itemId][tier] then
						result[itemId][tier] = 0
					end
					result[itemId][tier] = result[itemId][tier] + 1
				end
			end
			if itemType:isContainer() then
				searchContainer(result, slotItem)
			end	
		end
	end
	return result
end

function createFromTable(table)
	local msg = NetworkMessage()
	for _, data in pairs(table) do
		if data[1] == 1 then
			msg:addByte(data[2])
		elseif data[1] == 2 then
			msg:addU16(data[2])
		elseif data[1] == 4 then
			msg:addU32(data[2])
		elseif data[1] == 8 then
			msg:addU64(data[2])
		else
			msg:addString(data[1])
		end
	end
	return msg
end

function Player.openExaltationForge(player)

	player:sendForgingData()

	local msg = NetworkMessage()
	msg:addByte(Exaltation_Forge.Server_Packets.OpenForge)
	
	local upgradableItems = player:getUpgradableItems()
	local fusionTotal, transferTotal, receiverTotal = 0, 0, 0
	for itemId, data in pairs(upgradableItems) do
		for tier, count in pairs(data) do
			if count > 1 then
				fusionTotal = fusionTotal + 1
			end
			if tier > 1 then
				transferTotal = transferTotal + 1
			end
			if tier == 0 then
				receiverTotal = receiverTotal + 1
			end
		end
	end
	
	msg:addByte(math.min(255, fusionTotal)) -- fusion count
	
	for itemId, data in pairs(upgradableItems) do
		for tier, count in pairs(data) do
			if count > 1 then
				msg:addByte(0x00) -- Item Start ¿?
				msg:addByte(count < 256 and 1 or 2)
				msg:addU16(ItemType(itemId):getClientId())
				msg:addByte(tier)
				msg:addByte(count % 256)
				if count >= 256 then
					msg:addU32(math.floor(count / 256))
				end
			end
		end
	end
	
	msg:addByte(0x00) -- fusion end
	
	local transferEnabled = transferTotal > 0
	
	msg:addByte(transferEnabled and 0x01 or 0x00)
	
	if transferEnabled then
		msg:addByte(math.min(255, transferTotal)) -- transfer count
		
		for itemId, data in pairs(upgradableItems) do
			for tier, count in pairs(data) do
				if tier > 1 then
					msg:addByte(0x00) -- Item Start
					msg:addU16(ItemType(itemId):getClientId())
					msg:addByte(tier)
					msg:addByte(count)
				end
			end
		end
		
		msg:addByte(0x00) -- transfer end
		msg:addByte(math.min(255, receiverTotal)) -- receiver count
		
		for itemId, data in pairs(upgradableItems) do
			for tier, count in pairs(data) do
				if tier == 0 then
					msg:addByte(0x00) -- Item Start
					msg:addU16(ItemType(itemId):getClientId())
					msg:addByte(count)
				end
			end
		end
		
		msg:addByte(0x00) -- receiver end
	end
	
	-- /lua local t = {{1, 0x87},{1,1},{1,0},{1,1},{2,37608},{1,1},{1,2},{1,0},{1,1},{2,1},{2,3392},{1,2},{2,0},{2,0},{1,0}} local msg = createFromTable(t) msg:sendToPlayer(Player("Hyresex"))
	msg:addByte(player:getMaximumDust())
	msg:addResource(Exaltation_Forge.Resource_Type.Dust, player:getDust())
	msg:addResource(Exaltation_Forge.Resource_Type.Slivers, player:getItemCount(Exaltation_Forge.Config.Sliver_Id))
	msg:addResource(Exaltation_Forge.Resource_Type.Exalted_Cores, player:getItemCount(Exaltation_Forge.Config.Exalted_Core_Id))
	msg:addResource(Exaltation_Forge.Resource_Type.Bank, player:getBankBalance())
	msg:addResource(Exaltation_Forge.Resource_Type.Inventory, player:getMoney())
	msg:sendToPlayer(player)
end